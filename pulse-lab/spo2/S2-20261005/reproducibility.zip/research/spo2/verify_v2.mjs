import fs from 'node:fs';import assert from 'node:assert/strict';
import {preprocessRGB,spectralFeatures,predictSpectral,predictBounded,validateSpO2Model,OxygenCollector} from '../../dist/spo2-model.mjs';
const read=p=>JSON.parse(fs.readFileSync(p));let neuralError=0,spectralError=0,featureError=0;
const model=validateSpO2Model(read('research/spo2/results_bounded/model.json'));
const cases=read('research/spo2/results_bounded/parity_cases.json');
for(const c of cases)neuralError=Math.max(neuralError,Math.abs(predictBounded(model,preprocessRGB(c.rgb))-c.prediction));
const spectral=validateSpO2Model(read('research/spo2/results_v2/model.json'));
for(const c of read('research/spo2/results_v2/parity_cases.json')){
  const f=spectralFeatures(preprocessRGB(c.rgb));featureError=Math.max(featureError,...f.map((v,i)=>Math.abs(v-c.features[i])));spectralError=Math.max(spectralError,Math.abs(predictSpectral(spectral,f)-c.prediction));
}
assert(neuralError<.0001);assert(spectralError<.0001);assert(featureError<.0001);
const collector=new OxygenCollector(),raw=cases[1].rgb;
for(let i=0;i<1200;i++){const t=i/30,rgb=raw[i%180];collector.push({t,frameTimingVerified:true,oxygen:{r:rgb[0],g:rgb[1],b:rgb[2],clipped:[0,0,0]}},model,t,{torch:'on'})}
assert(collector.summary(40,model).ready);assert(collector.summary(40,model).prediction.lowRangeBias===model.low_range_bias);
for(const name of ['results_bounded','results_v2'])for(const fold of read(`research/spo2/${name}/metrics.json`).folds){const ids=fold.refit_training_subjects||fold.training_subjects;assert(!ids.includes(fold.test_subject));if(fold.epoch_training_subjects){assert(!fold.epoch_training_subjects.includes(fold.test_subject));assert(!fold.epoch_training_subjects.includes(fold.epoch_validation_subject))}}
const result={status:'passed',neural_parity_cases:cases.length,max_neural_error_pp:neuralError,max_spectral_error_pp:spectralError,max_spectral_feature_error:featureError,real_rgb_pipeline:true,participant_separation:true};
fs.writeFileSync('research/spo2/results_bounded/verification.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
