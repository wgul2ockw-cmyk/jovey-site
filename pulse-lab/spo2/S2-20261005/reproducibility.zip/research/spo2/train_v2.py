"""Second exploratory attempt: pulse-band optical features and nested selection.

The cohort has been seen in v1. This is exploratory development, not a new
independent clinical test. Each nested outer fold nevertheless excludes its
test participant from feature scaling, fitting and candidate selection.
"""
import argparse,json,time,itertools,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler,PolynomialFeatures
from sklearn.linear_model import Ridge
from sklearn.svm import SVR
from sklearn.ensemble import ExtraTreesRegressor
from train_spo2 import read_data,metrics,json_save,SEED

def optical_features(rgb):
    n=len(rgb);t=np.arange(n)-(n-1)/2;dc=rgb.mean(0)
    ac=rgb/dc-1;ac-=t[:,None]*(ac*t[:,None]).sum(0)/(t*t).sum()
    hann=.5-.5*np.cos(2*np.pi*np.arange(n)/(n-1))
    spectrum=np.fft.rfft(ac*hann[:,None],axis=0)
    power=np.abs(spectrum)**2
    # Fixed 0.67–3.5 Hz band at 30 Hz/180 frames: bins 4..21.
    band=np.sqrt(np.maximum(power[4:22].sum(0),1e-12))
    k=4+int(np.argmax(power[4:19,1]))
    pulse=np.sqrt(np.maximum(power[max(4,k-1):min(22,k+2)].sum(0),1e-12))
    rms=np.maximum(np.sqrt((ac*ac).mean(0)),1e-8)
    ratio=lambda a:np.log(np.array([a[0]/a[1],a[0]/a[2],a[1]/a[2]]))
    # First nine are multiplicative-gain-invariant log AC/DC ratios.
    # Final six add common perfusion amplitude and within-band concentration.
    return np.r_[ratio(band),ratio(pulse),ratio(rms),np.log(band),np.log(np.maximum(pulse/band,1e-8))].astype(np.float64)

CANDIDATES=[]
for cols in ['ratios','all']:
    for c,g in [(3,.1),(10,.1),(30,.1),(10,.5),(30,.5)]:
        CANDIDATES.append(dict(id=f'svr-{cols}-C{c}-g{g}',kind='svr',cols=cols,C=c,gamma=g))
    for depth in [4,7]:CANDIDATES.append(dict(id=f'trees-{cols}-d{depth}',kind='trees',cols=cols,depth=depth))
    for alpha in [10,100]:CANDIDATES.append(dict(id=f'ridge-{cols}-a{alpha}',kind='ridge',cols=cols,alpha=alpha))

def subset(x,c):return x[:,:9] if c['cols']=='ratios' else x
def estimator(c):
    if c['kind']=='svr':return make_pipeline(StandardScaler(),SVR(C=c['C'],gamma=c['gamma'],epsilon=.5))
    if c['kind']=='trees':return ExtraTreesRegressor(n_estimators=96,max_depth=c['depth'],min_samples_leaf=12,max_features=1.,random_state=SEED,n_jobs=2)
    return make_pipeline(StandardScaler(),Ridge(alpha=c['alpha']))

def weights(y,g):
    # Training-only balancing of each participant x saturation-band cell.
    band=np.digitize(y,[80,90]);w=np.zeros(len(y))
    for subject in np.unique(g):
        for b in np.unique(band[g==subject]):
            ix=(g==subject)&(band==b);w[ix]=1/ix.sum()
    return w/w.mean()

def fit(c,x,y,g,train):
    est=estimator(c);wt=weights(y[train],g[train]);kwargs={'sample_weight':wt} if c['kind']=='trees' else {('svr' if c['kind']=='svr' else 'ridge')+'__sample_weight':wt}
    est.fit(subset(x[train],c),y[train],**kwargs);return est

def score(y,p,g):
    errors=[]
    for subject in np.unique(g):
        for lo,hi in [(70,80),(80,90),(90,101)]:
            ix=(g==subject)&(y>=lo)&(y<hi)
            if ix.any():errors.append(float(np.abs(p[ix]-y[ix]).mean()))
    return float(np.mean(errors))

def export(est,c,x,y,report):
    model=dict(id='spo2-hoffman-spectral-20261005',feature_version='rgb-spectral-v2',kind='spectral_'+c['kind'],frames=180,fps=30,window_seconds=6,candidate=c,feature_count=9 if c['cols']=='ratios' else 15,feature_min=subset(x,c).min(0),feature_max=subset(x,c).max(0),participants=6,phone_validated=False,benchmark=report['metrics'],macro_mae=report['macro_mae'],low_range_bias=report['bands']['70-80']['bias'],source='https://github.com/ubicomplab/oximetry-phone-cam-data',license='MIT; see hoffman-LICENSE.txt',selection=report['evaluation_status'])
    if c['kind']=='trees':
        model['trees']=[dict(children_left=e.tree_.children_left,children_right=e.tree_.children_right,feature=e.tree_.feature,threshold=e.tree_.threshold,value=e.tree_.value[:,0,0]) for e in est.estimators_]
    else:
        scaler=est.named_steps['standardscaler'];reg=est[-1]
        model.update(feature_mean=scaler.mean_,feature_scale=scaler.scale_)
        if c['kind']=='svr':model.update(support_vectors=reg.support_vectors_,dual_coefficients=reg.dual_coef_[0],intercept=float(reg.intercept_[0]),gamma=float(reg._gamma))
        else:model.update(coefficients=reg.coef_,intercept=float(reg.intercept_))
    return model

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);args=p.parse_args();out=Path(__file__).parent/'results_v2';out.mkdir(exist_ok=True)
    raw,_,_,y,meta,audit=read_data(args.data);x=np.array([optical_features(r) for r in raw]);g=np.array([m['subject'] for m in meta]);subjects=sorted(set(g));start=time.time()
    json_save(out/'protocol.json',dict(candidates=CANDIDATES,objective='Unweighted mean of MAE across participant x reference-saturation-band cells (70-80,80-90,90-100).',weighting='Training participant x saturation-band balanced sample weights, mean normalized to one.',feature_transform='Hann-windowed DFT of fractionally normalized and linearly detrended RGB; fixed pulse band and green-peak neighbourhood ratios.',prior_cohort_exposure=True))
    print(json.dumps(dict(event='start',candidates=len(CANDIDATES),windows=len(y),protocol='nested group selection with participant-band balanced objective')),flush=True)
    # Shared pair exclusions reuse the same four-subject training fit without
    # crossing outer-fold boundaries. Predict each excluded subject separately.
    cache={}
    for a,b in itertools.combinations(subjects,2):
        train=np.flatnonzero((g!=a)&(g!=b))
        for c in CANDIDATES:
            est=fit(c,x,y,g,train)
            for valid in [a,b]:
                ids=np.flatnonzero(g==valid);cache[(a,b,c['id'],valid)]=est.predict(subset(x[ids],c))
    oof=np.zeros(len(y));folds=[];final_candidate_oof={c['id']:np.zeros(len(y)) for c in CANDIDATES}
    for heldout in subjects:
        other=[s for s in subjects if s!=heldout];scores={}
        for c in CANDIDATES:
            ys=[];preds=[];groups=[]
            for valid in other:
                a,b=sorted([heldout,valid]);ids=np.flatnonzero(g==valid)
                ys.extend(y[ids]);preds.extend(cache[(a,b,c['id'],valid)]);groups.extend(g[ids])
            scores[c['id']]=score(np.array(ys),np.array(preds),np.array(groups))
        chosen=min(CANDIDATES,key=lambda c:scores[c['id']]);train=np.flatnonzero(g!=heldout);test=np.flatnonzero(g==heldout)
        for c in CANDIDATES:
            est=fit(c,x,y,g,train);pred=est.predict(subset(x[test],c));final_candidate_oof[c['id']][test]=pred
            if c['id']==chosen['id']:oof[test]=pred
        fold=dict(test_subject=heldout,training_subjects=other,selected=chosen,inner_scores=scores,metrics=metrics(y[test],oof[test]))
        folds.append(fold);print(json.dumps(dict(event='outer_fold',**{k:v for k,v in fold.items() if k!='inner_scores'})),flush=True)
    final_scores={c['id']:score(y,final_candidate_oof[c['id']],g) for c in CANDIDATES}
    chosen=min(CANDIDATES,key=lambda c:final_scores[c['id']]);est=fit(chosen,x,y,g,np.arange(len(y)))
    bands={}
    for lo,hi in [(70,80),(80,90),(90,101)]:
        ix=(y>=lo)&(y<hi);bands[f'{lo}-{min(hi,100)}']=metrics(y[ix],oof[ix])
    report=dict(id='spo2-experiment-v2',windows=len(y),participants=6,audit=audit,folds=folds,metrics=metrics(y,oof),macro_mae=float(np.mean([f['metrics']['mae'] for f in folds])),balanced_mae=score(y,oof,g),bands=bands,final_selected=chosen,final_selection_scores=final_scores,evaluation_status='Nested leave-one-participant-out evaluation of the selection procedure. Each outer subject excluded from fitting, scaling and model selection. Six-person cohort already examined in v1: exploratory development, not independent external validation. Final all-six fit has no untouched test cohort.',elapsed_seconds=time.time()-start,seed=SEED,phone_validated=False)
    json_save(out/'metrics.json',report);json_save(out/'model.json',export(est,chosen,x,y,report))
    df=pd.DataFrame(meta);df['reference']=y;df['prediction']=oof;df.to_csv(out/'oof_predictions.csv',index=False)
    cases=[];examples=[]
    for subject in subjects:
        ids=np.flatnonzero(g==subject);j=ids[len(ids)//2]
        cases.append(dict(**meta[j],rgb=raw[j],features=x[j],prediction=float(est.predict(subset(x[j:j+1],chosen))[0])))
        for lo,hi in [(70,80),(80,90),(90,101)]:
            ix=np.flatnonzero((g==subject)&(y>=lo)&(y<hi))
            if len(ix):
                k=ix[len(ix)//2];examples.append(dict(**meta[k],reference=float(y[k]),prediction=float(oof[k]),origin='Stored prediction from nested outer fold, with participant excluded from candidate selection and fitting.'))
    json_save(out/'parity_cases.json',cases);json_save(out/'examples.json',examples)
    print(json.dumps(dict(event='complete',metrics=report['metrics'],macro_mae=report['macro_mae'],balanced_mae=report['balanced_mae'],bands=bands,selected=chosen,seconds=report['elapsed_seconds'])),flush=True)

if __name__=='__main__':main()
