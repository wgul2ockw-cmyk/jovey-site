"""Bounded CNN revision; same six-person development cohort, not external validation."""
import argparse,json,time
from pathlib import Path
import numpy as np,pandas as pd,torch
from torch import nn
from train_spo2 import read_data,Net,norm_fit,tensors,metrics,json_save,SEED,VERSION
from train_v2 import weights

class BoundedNet(Net):
    def forward(self,w,f):
        x=torch.relu(self.c1(w))
        x=torch.relu(x+self.c2(x));x=nn.functional.avg_pool1d(x,3)
        x=torch.relu(self.c3(x));x=nn.functional.avg_pool1d(x,3)
        z=torch.cat([x.mean(2),x.amax(2),f],1)
        z=nn.functional.dropout(torch.relu(self.fc1(z)),p=.15,training=self.training)
        return 3*(torch.sigmoid(self.fc2(z).squeeze(1))-.5)

def fit(w,f,y,g,train,val=None,epochs=100,seed=SEED):
    torch.manual_seed(seed);norm=norm_fit(w,f,train);wt,ft,yt=tensors(w,f,y,norm)
    wt=wt.clamp(-6,6);ft=ft.clamp(-6,6)
    net=BoundedNet();opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.01);rng=np.random.default_rng(seed)
    sw=np.ones(len(y));sw[train]=weights(y[train],g[train]);sw=torch.tensor(sw,dtype=torch.float32)
    best=float('inf');best_state=None;chosen=epochs;stale=0
    for ep in range(1,epochs+1):
        net.train()
        for batch in np.array_split(rng.permutation(train),int(np.ceil(len(train)/128))):
            opt.zero_grad(set_to_none=True);pred=net(wt[batch],ft[batch])
            loss=(nn.functional.smooth_l1_loss(pred,yt[batch],beta=.5,reduction='none')*sw[batch]).mean();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),5);opt.step()
        if val is not None:
            net.eval()
            with torch.no_grad():error=torch.abs(net(wt[val],ft[val])-yt[val]).numpy()*10
            # A fixed equal-band objective reduces dominance by normal-range data.
            score=np.mean([error[(y[val]>=lo)&(y[val]<hi)].mean() for lo,hi in [(70,80),(80,90),(90,101)] if np.any((y[val]>=lo)&(y[val]<hi))])
            if score<best-1e-4:best=float(score);chosen=ep;best_state={k:v.detach().clone() for k,v in net.state_dict().items()};stale=0
            else:stale+=1
            if ep>=25 and stale>=16:break
    if val is not None:net.load_state_dict(best_state)
    net.eval();return net,norm,chosen

def predict(net,norm,w,f):
    wt,ft,_=tensors(w,f,np.zeros(len(w),np.float32),norm)
    with torch.no_grad():return (net(wt.clamp(-6,6),ft.clamp(-6,6))*10+85).numpy()

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);args=p.parse_args();out=Path(__file__).parent/'results_bounded';out.mkdir(exist_ok=True);start=time.time()
    raw,w,f,y,meta,audit=read_data(args.data);f[:,6:8]=0;g=np.array([m['subject'] for m in meta]);subjects=sorted(set(g));oof=np.zeros(len(y));folds=[];all_epochs=[]
    print(json.dumps(dict(event='start',protocol='Bounded CNN, DC colour features masked, normalized inputs clipped at six SD, dropout .15, weight decay .01, participant/band-balanced Huber loss, two-seed ensemble.')),flush=True)
    for i,subject in enumerate(subjects):
        val_subject=subjects[(i+1)%6];train=np.flatnonzero((g!=subject)&(g!=val_subject));val=np.flatnonzero(g==val_subject);test=np.flatnonzero(g==subject);remaining=np.flatnonzero(g!=subject)
        preds=[];epochs=[]
        for seed in [SEED,SEED+41]:
            _,_,ep=fit(w,f,y,g,train,val,seed=seed+i)
            net,norm,_=fit(w,f,y,g,remaining,epochs=ep,seed=seed+i)
            preds.append(predict(net,norm,w[test],f[test]));epochs.append(ep)
        oof[test]=np.mean(preds,0);all_epochs.extend(epochs)
        fold=dict(test_subject=subject,epoch_validation_subject=val_subject,epoch_training_subjects=[s for s in subjects if s not in [subject,val_subject]],refit_training_subjects=[s for s in subjects if s!=subject],epochs=epochs,metrics=metrics(y[test],oof[test]));folds.append(fold);print(json.dumps(dict(event='fold',**fold)),flush=True)
    members=[];final_preds=[];ep=int(np.median(all_epochs))
    for seed in [SEED,SEED+41]:
        net,norm,_=fit(w,f,y,g,np.arange(len(y)),epochs=ep,seed=seed)
        members.append(dict(normalization=norm,weights={k:v.detach().numpy() for k,v in net.state_dict().items()},mask_dc=True,input_clip=6,output_activation='sigmoid',output_offset=70,output_scale=30))
        final_preds.append(predict(net,norm,w,f))
    bands={}
    for lo,hi in [(70,80),(80,90),(90,101)]:
        ix=(y>=lo)&(y<hi);bands[f'{lo}-{min(hi,100)}']=metrics(y[ix],oof[ix])
    report=dict(id='spo2-bounded-cnn-v2',windows=len(y),participants=6,metrics=metrics(y,oof),macro_mae=float(np.mean([a['metrics']['mae'] for a in folds])),bands=bands,folds=folds,final_epochs=ep,seconds=time.time()-start,phone_validated=False,evaluation_status='Participant-held-out development evaluation on the same six-person cohort already examined in prior attempts. No independent final test cohort. Epoch choice excludes each outer test participant; two-seed prediction ensemble.')
    artifact=dict(id='spo2-hoffman-bounded-cnn-20261005',kind='bounded_cnn_ensemble',feature_version=VERSION,fps=30,frames=180,window_seconds=6,members=members,feature_min=f[:,3:6].min(0),feature_max=f[:,3:6].max(0),participants=6,phone_validated=False,benchmark=report['metrics'],macro_mae=report['macro_mae'],low_range_bias=bands['70-80']['bias'],source='https://github.com/ubicomplab/oximetry-phone-cam-data',selection=report['evaluation_status'])
    json_save(out/'model.json',artifact);json_save(out/'metrics.json',report)
    df=pd.DataFrame(meta);df['reference']=y;df['prediction']=oof;df.to_csv(out/'oof_predictions.csv',index=False)
    cases=[];examples=[]
    for subject in subjects:
        ids=np.flatnonzero(g==subject);j=ids[len(ids)//2]
        cases.append(dict(**meta[j],rgb=raw[j],features=f[j],prediction=float(np.mean(final_preds,0)[j])))
        for lo,hi in [(70,80),(80,90),(90,101)]:
            ix=np.flatnonzero((g==subject)&(y>=lo)&(y<hi))
            if len(ix):
                k=ix[len(ix)//2];examples.append(dict(**meta[k],reference=float(y[k]),prediction=float(oof[k]),origin='Stored outer-fold bounded-CNN ensemble prediction; participant excluded from fitting and epoch selection.'))
    json_save(out/'parity_cases.json',cases);json_save(out/'examples.json',examples)
    print(json.dumps(dict(event='complete',metrics=report['metrics'],macro_mae=report['macro_mae'],bands=bands,epochs=ep,seconds=report['seconds'])),flush=True)

if __name__=='__main__':main()
