"""Reproducible camera RGB -> SpO2 research baseline. No patient calibration.

Nested participant separation: each outer test subject is absent from training,
normalization and epoch selection. A different remaining subject selects epochs;
then refit on all five non-test participants. Both hands stay in the same fold.
"""
import argparse, hashlib, json, math, platform, subprocess, time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

SEED = 20261005
FPS, N = 30, 180
VERSION = 'rgb-acdc-rescnn-v1'
FEATURES = ['log_pi_r','log_pi_g','log_pi_b','log_ratio_rg','log_ratio_rb','log_ratio_gb','log_dc_gr','log_dc_br']
torch.set_num_threads(2)
torch.use_deterministic_algorithms(True)

def preprocess(rgb):
    rgb = np.asarray(rgb, dtype=np.float64)
    dc = rgb.mean(axis=0)
    centered = rgb / dc - 1
    t = np.arange(N, dtype=np.float64) - (N-1)/2
    slope = (centered * t[:,None]).sum(axis=0) / (t*t).sum()
    wave = (centered - t[:,None]*slope) * 100
    rms = np.maximum(np.sqrt((wave*wave).mean(axis=0)), 1e-6)
    features = np.array([*np.log(rms), np.log(rms[0]/rms[1]), np.log(rms[0]/rms[2]), np.log(rms[1]/rms[2]), np.log(dc[1]/dc[0]), np.log(dc[2]/dc[0])])
    return wave.T.astype(np.float32), features.astype(np.float32), dc, rms

def read_data(root):
    raw, wave, features, ys, meta, audit = [], [], [], [], [], []
    for file in sorted((root/'data/gt').glob('100*.csv')):
        subject = file.stem
        gt = pd.read_csv(file); gt.columns = gt.columns.str.strip()
        labels = pd.to_numeric(gt['SpO2 5'], errors='coerce').to_numpy()
        for hand in ['Left','Right']:
            x = pd.read_csv(root/f'data/ppg-csv/{hand}/{subject}.csv')[['R','G','B']].to_numpy()
            counts = dict(subject=subject,hand=hand,frames=len(x),accepted=0,invalid_label=0,invalid_rgb=0)
            # Discard a fixed first six seconds, independent of reference values.
            for start in range(N, min(len(x),len(labels)*FPS)-N+1, N):
                rgb=x[start:start+N]; y=labels[start//FPS:(start+N)//FPS]
                if len(y)!=6 or not np.isfinite(y).all() or (y<70).any() or (y>100).any():
                    counts['invalid_label']+=1; continue
                if not np.isfinite(rgb).all() or (rgb.mean(0)<=3).any() or (rgb.mean(0)>=250).any():
                    counts['invalid_rgb']+=1; continue
                w,f,dc,rms=preprocess(rgb)
                if not np.isfinite(f).all() or (rms<.005).any():
                    counts['invalid_rgb']+=1; continue
                raw.append(rgb);wave.append(w);features.append(f);ys.append(y.mean())
                meta.append(dict(subject=subject,hand=hand,start_seconds=start/FPS))
                counts['accepted']+=1
            audit.append(counts)
    return np.array(raw),np.array(wave),np.array(features),np.array(ys,dtype=np.float32),meta,audit

class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.c1=nn.Conv1d(3,12,7,padding=3)
        self.c2=nn.Conv1d(12,12,5,padding=2)
        self.c3=nn.Conv1d(12,16,5,padding=2)
        self.fc1=nn.Linear(40,24)
        self.fc2=nn.Linear(24,1)
    def forward(self,w,f):
        x=torch.relu(self.c1(w))
        x=torch.relu(x+self.c2(x))
        x=nn.functional.avg_pool1d(x,3)
        x=torch.relu(self.c3(x))
        x=nn.functional.avg_pool1d(x,3)
        x=torch.cat([x.mean(2),x.amax(2),f],1)
        return self.fc2(torch.relu(self.fc1(x))).squeeze(1)

def norm_fit(w,f,ids):
    return dict(wave_scale=np.maximum(w[ids].std(axis=(0,2)),1e-4),feature_mean=f[ids].mean(0),feature_scale=np.maximum(f[ids].std(0),1e-4))

def tensors(w,f,y,norm):
    return (torch.tensor(w/norm['wave_scale'][None,:,None]),torch.tensor((f-norm['feature_mean'])/norm['feature_scale']),torch.tensor((y-85)/10))

def fit(w,f,y,train,val=None,epochs=100,seed=SEED):
    torch.manual_seed(seed);np.random.seed(seed)
    norm=norm_fit(w,f,train); wt,ft,yt=tensors(w,f,y,norm)
    net=Net();opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.001)
    rng=np.random.default_rng(seed); best=float('inf');chosen=epochs;best_state=None;stale=0
    for epoch in range(1,epochs+1):
        net.train()
        for batch in np.array_split(rng.permutation(train),math.ceil(len(train)/128)):
            opt.zero_grad(set_to_none=True)
            loss=nn.functional.smooth_l1_loss(net(wt[batch],ft[batch]),yt[batch],beta=.5)
            loss.backward();nn.utils.clip_grad_norm_(net.parameters(),5);opt.step()
        if val is not None:
            net.eval()
            with torch.no_grad():score=float(torch.abs(net(wt[val],ft[val])-yt[val]).mean())
            if score<best-1e-5:
                best=score;chosen=epoch;best_state={k:v.detach().clone() for k,v in net.state_dict().items()};stale=0
            else:stale+=1
            if epoch>=20 and stale>=14:break
    if val is not None:net.load_state_dict(best_state)
    net.eval()
    return net,norm,chosen

def predict(net,norm,w,f):
    wt,ft,_=tensors(w,f,np.zeros(len(w),np.float32),norm)
    with torch.no_grad():return (net(wt,ft)*10+85).numpy()

def metrics(y,p):
    e=p-y
    return dict(n=len(y),mae=float(np.abs(e).mean()),rmse=float(np.sqrt((e*e).mean())),bias=float(e.mean()),absolute_error_p90=float(np.quantile(np.abs(e),.9)))

def json_save(path,obj):
    def cast(x):
        if isinstance(x,np.ndarray):return x.tolist()
        if isinstance(x,np.generic):return x.item()
        raise TypeError(str(type(x)))
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,default=cast,allow_nan=False,separators=(',',':'))+'\n')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    start_time=time.time()
    raw,w,f,y,meta,audit=read_data(args.data)
    groups=np.array([m['subject'] for m in meta]);subjects=sorted(set(groups))
    oof={k:np.zeros(len(y)) for k in ['cnn','ratio_ridge','constant']};folds=[];epochs=[]
    print(json.dumps(dict(event='data_ready',windows=len(y),participants=subjects,audit=audit)),flush=True)
    for i,subject in enumerate(subjects):
        validation=subjects[(i+1)%len(subjects)]
        train=np.flatnonzero((groups!=subject)&(groups!=validation));val=np.flatnonzero(groups==validation);test=np.flatnonzero(groups==subject)
        _,_,epoch=fit(w,f,y,train,val,seed=SEED+i)
        remaining=np.flatnonzero(groups!=subject)
        net,norm,_=fit(w,f,y,remaining,epochs=epoch,seed=SEED+i)
        oof['cnn'][test]=predict(net,norm,w[test],f[test]);epochs.append(epoch)
        ridge=make_pipeline(StandardScaler(),Ridge(alpha=10))
        ridge.fit(f[remaining,3:6],y[remaining]);oof['ratio_ridge'][test]=ridge.predict(f[test,3:6])
        oof['constant'][test]=np.median(y[remaining])
        fold=dict(test_subject=subject,epoch_validation_subject=validation,epoch_training_subjects=subjects[:i]+subjects[i+1:],epochs=epoch,train_windows=len(remaining),test_windows=len(test),metrics={k:metrics(y[test],p[test]) for k,p in oof.items()})
        # Record both distinct fitting stages explicitly.
        fold['epoch_training_subjects']=[s for s in subjects if s not in [subject,validation]]
        fold['refit_training_subjects']=[s for s in subjects if s!=subject]
        folds.append(fold);print(json.dumps(dict(event='fold_done',**fold)),flush=True)
    final_epochs=int(np.median(epochs)); net,norm,_=fit(w,f,y,np.arange(len(y)),epochs=final_epochs)
    predictions=pd.DataFrame(meta);predictions['reference']=y
    for k,v in oof.items():predictions[k]=v
    args.out.mkdir(parents=True,exist_ok=True);predictions.to_csv(args.out/'oof_predictions.csv',index=False)
    bands={}
    for lo,hi in [(70,80),(80,90),(90,101)]:
        ix=(y>=lo)&(y<hi);bands[f'{lo}-{min(hi,100)}']=dict(n=int(ix.sum()),**{k:metrics(y[ix],p[ix]) for k,p in oof.items()})
    report=dict(model_id='spo2-hoffman-rescnn-20261005',feature_version=VERSION,seed=SEED,created_at=pd.Timestamp.now(tz='UTC').isoformat(),dataset_url='https://github.com/ubicomplab/oximetry-phone-cam-data',dataset_commit=subprocess.check_output(['git','-C',str(args.data),'rev-parse','HEAD'],text=True).strip(),data_license='MIT',participants=len(subjects),windows=len(y),fps=FPS,window_seconds=6,label='Arithmetic mean of six 1 Hz Masimo SpO2 5 observations, aligned by recording start as documented by the dataset. No reference-guided lag fitting.',label_range=[float(y.min()),float(y.max())],audit=audit,folds=folds,pooled={k:metrics(y,p) for k,p in oof.items()},subject_macro_mae={k:float(np.mean([a['metrics'][k]['mae'] for a in folds])) for k in oof},saturation_bands=bands,final_epochs=final_epochs,final_fit_participants=subjects,final_model_evaluation='Final model refit on all six participants. Reported evaluation is from six separate outer-fold models; the final fit has no independent test cohort.',phone_validated=False,uncertainty='No calibrated individual prediction interval. Window spread is not an accuracy interval.',limitations=['Six participants, one Nexus 6P phone model; no independent iPhone or browser cohort.','Pulse oximeter reference rather than arterial co-oximetry.','Alignment uses nominal 30 Hz and shared recording start; sensor averaging/lag remain limitations.','Raw frame means from whole-frame decoded video; browser exposure, white balance, processing and flash differ.','No clinical threshold, hypoxemia triage, skin-tone subgroup, personalization or glucose validation.','Adjacent nonoverlapping windows remain correlated; participant count is the effective generalization sample size.','Live signal gates are provisional engineering rules, not clinical validation.'],runtime=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__),elapsed_seconds=time.time()-start_time)
    report['release_decision']='Experimental only. Fixed CNN candidate; baseline comparisons are reported without claiming clinical readiness.'
    json_save(args.out/'metrics.json',report)
    weights={k:v.detach().numpy() for k,v in net.state_dict().items()}
    artifact=dict(id=report['model_id'],feature_version=VERSION,architecture='Conv3to12-k7, residual12-k5, avgpool3, Conv12to16-k5, avgpool3, mean+max, concat8, Dense24, Dense1',fps=FPS,frames=N,window_seconds=6,normalization=norm,weights=weights,output_offset=85,output_scale=10,training_domain=dict(feature_min=f.min(0),feature_max=f.max(0)),features=FEATURES,benchmark=report['pooled']['cnn'],macro_mae=report['subject_macro_mae']['cnn'],participants=6,phone_validated=False,license='MIT; see hoffman-LICENSE.txt',source=report['dataset_url'])
    json_save(args.out/'model.json',artifact)
    ridge_final=make_pipeline(StandardScaler(),Ridge(alpha=10)).fit(f[:,3:6],y)
    scaler=ridge_final.named_steps['standardscaler'];reg=ridge_final.named_steps['ridge']
    ratio_artifact=dict(id='spo2-hoffman-ratio-20261005',feature_version=VERSION,kind='ratio_ridge',fps=FPS,frames=N,window_seconds=6,feature_indices=[3,4,5],feature_mean=scaler.mean_,feature_scale=scaler.scale_,coefficients=reg.coef_,intercept=float(reg.intercept_),feature_min=f[:,3:6].min(0),feature_max=f[:,3:6].max(0),benchmark=report['pooled']['ratio_ridge'],macro_mae=report['subject_macro_mae']['ratio_ridge'],participants=6,phone_validated=False,source=report['dataset_url'],license='MIT; see hoffman-LICENSE.txt',selection='Ratio regression chosen after comparing these same six outer-fold results; comparison is exploratory and there is no untouched final test cohort.')
    json_save(args.out/'ratio_model.json',ratio_artifact)
    # One exported final-fit parity case per participant. These are explicitly not held-out demos.
    cases=[]
    for subject in subjects:
        ix=np.flatnonzero(groups==subject)[len(np.flatnonzero(groups==subject))//2]
        cases.append(dict(**meta[ix],rgb=raw[ix],features=f[ix],wave=w[ix],prediction=float(predict(net,norm,w[ix:ix+1],f[ix:ix+1])[0]),ratio_prediction=float(ridge_final.predict(f[ix:ix+1,3:6])[0])))
    json_save(args.out/'parity_cases.json',cases)
    # Real OOF examples contain predictions only: never run final-fit model and call it held out.
    demos=[]
    for subject in subjects:
        for lo,hi in [(70,80),(80,90),(90,101)]:
            inds=np.flatnonzero((groups==subject)&(y>=lo)&(y<hi))
            if len(inds):
                j=inds[len(inds)//2];demos.append(dict(**meta[j],reference=float(y[j]),prediction=float(oof['ratio_ridge'][j]),neural_prediction=float(oof['cnn'][j]),baseline=float(oof['constant'][j]),origin='Stored prediction from an outer-fold model that excluded this participant.'))
    json_save(args.out/'examples.json',demos)
    checksums={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in args.out.glob('*') if p.is_file() and p.name!='checksums.json'}
    json_save(args.out/'checksums.json',checksums)
    print(json.dumps(dict(event='complete',pooled=report['pooled'],macro_mae=report['subject_macro_mae'],epochs=final_epochs,seconds=report['elapsed_seconds'])),flush=True)

if __name__=='__main__':main()
