import fs from 'node:fs';
import assert from 'node:assert/strict';
import {preprocessRGB,predictRatio,predictCNN,validateSpO2Model,assessOxygenSegment,OxygenCollector} from '../../dist/spo2-model.mjs';
const read=p=>JSON.parse(fs.readFileSync(p));
const root='research/spo2/results/';
const model=validateSpO2Model(read(root+'ratio_model.json')),cnn=read(root+'model.json'),cases=read(root+'parity_cases.json');
let ratioError=0,cnnError=0,featureError=0;
for(const c of cases){
  const p=preprocessRGB(c.rgb);
  featureError=Math.max(featureError,...p.features.map((x,i)=>Math.abs(x-c.features[i])));
  ratioError=Math.max(ratioError,Math.abs(predictRatio(model,p.features)-c.ratio_prediction));
  cnnError=Math.max(cnnError,Math.abs(predictCNN(cnn,p)-c.prediction));
}
assert(ratioError<.0001,`ratio parity ${ratioError}`);assert(cnnError<.0001,`CNN parity ${cnnError}`);
const raw=cases[1].rgb;
const samples=Array.from({length:181},(_,i)=>({t:i/30,frameTimingVerified:true,oxygen:{r:raw[Math.min(i,179)][0],g:raw[Math.min(i,179)][1],b:raw[Math.min(i,179)][2],clipped:[0,0,0]}}));
assert(!assessOxygenSegment(samples,null,{torch:'on'}).accepted);
assert(!assessOxygenSegment(samples,model,{torch:'off'}).accepted);
assert(!assessOxygenSegment(samples.map(s=>({...s,frameTimingVerified:false})),model,{torch:'on'}).accepted);
assert(!assessOxygenSegment(samples.map(s=>({...s,oxygen:{...s.oxygen,clipped:[1,0,0]}})),model,{torch:'on'}).accepted);
assert(!assessOxygenSegment(samples.filter((_,i)=>i<30||i>60),model,{torch:'on'}).accepted);
assert(!assessOxygenSegment(samples.map(s=>({...s,oxygen:{r:100,g:100,b:100,clipped:[0,0,0]}})),model,{torch:'on'}).accepted);
assert(!assessOxygenSegment(samples.map(s=>({...s,oxygen:{...s.oxygen,g:NaN}})),model,{torch:'on'}).accepted);
assert(!assessOxygenSegment(samples,{...model,feature_min:[50,50,50]},{torch:'on'}).accepted);
const c=new OxygenCollector();
for(let i=0;i<3000;i++){const t=i/30,s=raw[i%raw.length];c.push({t,frameTimingVerified:true,oxygen:{r:s[0],g:s[1],b:s[2],clipped:[0,0,0]}},model,t,{torch:'on'})}
assert(c.bank.length>=3,'Real RGB replay produces eligible model segments');
const summary=c.summary(100,model);assert(summary.ready);assert(Number.isFinite(summary.prediction.value));
assert(c.bank.slice(1).every((s,i)=>s.start>=c.bank[i].end-1e-8),'Accepted six-second inference windows do not overlap');
const count=c.bank.length;c.resetContact();assert.equal(c.bank.length,count,'Contact reset retains prior accepted segments');
assert(c.buffer.length===0);assert(c.summary(300,model).prediction===null,'Expired segments cannot generate a readout');
const folds=read(root+'metrics.json').folds;
for(const f of folds){assert(!f.epoch_training_subjects.includes(f.test_subject));assert(!f.refit_training_subjects.includes(f.test_subject));assert(!f.epoch_training_subjects.includes(f.epoch_validation_subject));assert.equal(f.refit_training_subjects.length,5)}
const report={status:'passed',parity_cases:cases.length,max_ratio_error_pp:ratioError,max_cnn_error_pp:cnnError,max_feature_error:featureError,checks:['Python/JS feature and prediction parity','participant separation in both fitting stages','model unavailable','flash off','unverified timing','RGB clipping','frame gaps','flat signal','NaN','training-domain rejection','real RGB replay','nonoverlapping segments','contact reset','expiry']};
fs.writeFileSync(root+'verification.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
