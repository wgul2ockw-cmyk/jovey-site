# Pulse Lab SpO2 experiment 01

Actual trained artifacts and six-participant outer-fold predictions. Deployed
baseline: `spo2-hoffman-ratio-20261005`. Experimental only; iPhone/browser and
clinical accuracy are unknown. This is not the published paper's original model.

## Results (percentage points)

| Candidate | Pooled MAE | RMSE | Mean participant MAE |
| --- | ---: | ---: | ---: |
| RGB ratio ridge regression | 6.3775 | 7.8115 | 6.3854 |
| Residual RGB temporal CNN | 7.3946 | 9.8093 | 7.3602 |
| Training-median constant | 6.7481 | 8.1319 | 6.8177 |

The regression overestimates reference values below 80% by 11.50 points on
average. It is unsuitable for dependable hypoxemia screening. Family selection
used these same folds, so its evaluation is exploratory. No untouched cohort
tests the final artifact, refitted on all six participants.

## Reproduce

1. Install the dependencies in `requirements.txt` in a dedicated environment.
2. Clone https://github.com/ubicomplab/oximetry-phone-cam-data and check out the
   exact `dataset_commit` in `results/metrics.json`.
3. From the Pulse Lab repository root, run:

```sh
python research/spo2/train_spo2.py --data /absolute/path/to/oximetry-phone-cam-data --out research/spo2/results
node research/spo2/verify.mjs
```

No API key, GPU, patient data, or external service is needed for inference.
The run used CPU PyTorch, seed 20261005, and two computation threads. Exact
floating-point results can vary by library/platform version.

`train_spo2.py` fits the CNN, ratio and constant baselines in participant-held-out
folds and exports final CNN and regression weights, actual out-of-fold predictions,
fold definitions, parity cases and dataset audit. Both hands stay in a subject's
fold. CNN epoch selection uses four training subjects and one validation subject;
the sixth is absent from all selection/normalization. Each fold then refits on
the five non-test subjects. A single fixed hyperparameter set is used.

The first six seconds of each recording are discarded; subsequent windows have
180 frames and no overlap. Labels are window means from `SpO2 5` (Masimo), using
the repository's shared-start and nominal-30-Hz assumptions. Individual reference
values outside 70–100 or missing are excluded. There is no outcome-guided lag
correction. Metadata records exact exclusions. Label filtering limits the studied
range and does not validate extrapolation.

The CNN uses per-window fractional, linearly detrended RGB plus eight optical
features. Its waveform scale and feature standardization are fitted only on
training subjects. The regression uses standardized log RMS AC/DC ratios R/G,
R/B and G/B with ridge alpha=10. Deployment retains no participant ID, reference
label, elapsed-session index, or other target proxy as an input.

## Website integration

`dist/spo2-model.mjs` performs the same preprocessing and inference in JavaScript.
The app samples whole-frame RGB separately from the existing central BP region.
All camera frames and estimates remain in the tab unless the user exports them.
Six-second nonoverlapping windows are checked for confirmed browser-reported
flash, measured timing, channel clipping, repeatable variation and training-ratio
range. Three accepted windows produce an experimental average. These engineering
rules and scan averaging are not validated by the source-window accuracy metrics.

`results/parity_cases.json` is strictly for Python/JS equivalence (final-fit data).
The website's example button uses stored outer-fold predictions, never relabels
final-fit predictions as held out. The download report contains SpO2 provenance,
limitations, source-test errors and segment range, not a confidence interval.

Current BP, SpO2 and glucose training are not a jointly trained shared encoder.
Only the SpO2 neural candidate's encoder/head was trained in this experiment.
The regression was selected for deployment because the neural candidate performed
worse. BP weights and existing reference behavior are unchanged. No glucose or
SpO2 personalization capability is claimed.

## Files and license

- `results/metrics.json`: all participant and saturation-band results.
- `results/oof_predictions.csv`: real held-out predictions for every included window.
- `results/model.json`: full final-fit CNN weights.
- `results/ratio_model.json`: final-fit deployed regression coefficients.
- `results/training.log`: actual run log.
- `results/verification.json`: software parity and gate checks.
- `results/checksums.json`: artifact integrity hashes.

Data are supplied under the MIT license by the original authors; preserve
`hoffman-LICENSE.txt`. Cite Hoffman et al. (2022), Smartphone camera oximetry in
an induced hypoxemia study, npj Digital Medicine 5:146,
https://doi.org/10.1038/s41746-022-00665-y.
