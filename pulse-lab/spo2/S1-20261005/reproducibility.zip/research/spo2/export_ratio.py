"""Fit deployment ratio baseline without rerunning completed CNN evaluation."""
import argparse,json
from pathlib import Path
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from train_spo2 import read_data,json_save,VERSION
parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,required=True);args=parser.parse_args()
out=Path(__file__).parent/'results'
_,_,f,y,meta,_=read_data(args.data)
pipe=make_pipeline(StandardScaler(),Ridge(alpha=10)).fit(f[:,3:6],y)
sc=pipe.named_steps['standardscaler'];reg=pipe.named_steps['ridge']
report=json.loads((out/'metrics.json').read_text())
artifact=dict(id='spo2-hoffman-ratio-20261005',feature_version=VERSION,kind='ratio_ridge',fps=30,frames=180,window_seconds=6,feature_indices=[3,4,5],feature_mean=sc.mean_,feature_scale=sc.scale_,coefficients=reg.coef_,intercept=float(reg.intercept_),feature_min=f[:,3:6].min(0),feature_max=f[:,3:6].max(0),benchmark=report['pooled']['ratio_ridge'],macro_mae=report['subject_macro_mae']['ratio_ridge'],participants=6,phone_validated=False,source=report['dataset_url'],license='MIT; see hoffman-LICENSE.txt',selection='Ratio regression chosen after comparing these same six outer-fold results; comparison is exploratory and there is no untouched final test cohort.')
json_save(out/'ratio_model.json',artifact)
cases=json.loads((out/'parity_cases.json').read_text())
for c in cases:c['ratio_prediction']=float(pipe.predict(np.array(c['features'])[None,3:6])[0])
json_save(out/'parity_cases.json',cases)
demos=json.loads((out/'examples.json').read_text());import pandas as pd
oof=pd.read_csv(out/'oof_predictions.csv',dtype={'subject':str})
for c in demos:
    row=oof[(oof.subject==c['subject'])&(oof.hand==c['hand'])&(oof.start_seconds==c['start_seconds'])].iloc[0]
    c['neural_prediction']=float(row.cnn);c['prediction']=float(row.ratio_ridge);c['origin']='Stored prediction from an outer-fold model that excluded this participant.'
json_save(out/'examples.json',demos)
print((out/'ratio_model.json').read_text())
