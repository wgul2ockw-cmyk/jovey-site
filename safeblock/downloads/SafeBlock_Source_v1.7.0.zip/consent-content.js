"use strict";
(() => {
  if (!/^https?:$/.test(location.protocol) || globalThis.quietBlockConsentStarted) return;
  globalThis.quietBlockConsentStarted = true;
  const authorize = async () => {
    try { return (await chrome.runtime.sendMessage({ type: "bannerAllowed" }))?.allowed === true; }
    catch { return false; }
  };
  const engine = QuietBlockConsent.createEngine(document, window, authorize);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && "cookieBannerEnabled" in changes &&
        changes.cookieBannerEnabled.newValue !== true) engine.stop();
  });
  window.addEventListener("pagehide", () => engine.stop(), { once: true });
  authorize().then(allowed => { if (allowed) engine.start(); });
})();
