"use strict";
(() => {
  let player;
  let stopped = false;
  function stop() {
    stopped = true;
    player?.stop();
    window.dispatchEvent(new Event("quietblock-stop-youtube"));
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && "youtubeEnabled" in changes && changes.youtubeEnabled.newValue !== true) stop();
  });
  chrome.runtime.sendMessage({ type: "youtubeAllowed" }).then(state => {
    if (stopped || state?.allowed !== true) { stop(); return; }
    player = QuietBlockYouTubePlayer.createPlayer(document, window);
    player.start();
  }, stop);
  window.addEventListener("pagehide", stop, { once: true });
})();
