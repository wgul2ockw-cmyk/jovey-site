"use strict";
(() => {
  const adKeys = ["adPlacements", "playerAds", "adSlots"];
  const own = (object, key) => {
    if (!object || typeof object !== "object") return undefined;
    return Object.getOwnPropertyDescriptor(object, key)?.value;
  };
  function prune(root) {
    if (!root || typeof root !== "object") return root;
    const seen = new WeakSet();
    const queue = [[root, 0]];
    let examined = 0;
    while (queue.length && examined++ < 2000) {
      const [value, depth] = queue.shift();
      if (!value || typeof value !== "object" || seen.has(value)) continue;
      seen.add(value);
      const details = own(value, "videoDetails");
      const playability = own(value, "playabilityStatus");
      if (typeof own(details, "videoId") === "string" && typeof own(playability, "status") === "string") {
        for (const key of adKeys) {
          const descriptor = Object.getOwnPropertyDescriptor(value, key);
          if (descriptor?.configurable && Array.isArray(descriptor.value)) Reflect.deleteProperty(value, key);
        }
      }
      if (depth >= 8) continue;
      for (const key of Object.keys(value)) {
        const child = own(value, key); // Never invoke payload getters.
        if (child && typeof child === "object" && queue.length < 2000) queue.push([child, depth + 1]);
      }
    }
    return root;
  }

  function install(target) {
    let active = true;
    const originalParse = target.JSON.parse;
    const responsePrototype = target.Response?.prototype;
    const originalJSON = responsePrototype?.json;
    const originalInitial = Object.getOwnPropertyDescriptor(target, "ytInitialPlayerResponse");
    let initialValue = originalInitial?.value;
    let initialAssigned = !!originalInitial;
    const clean = value => { if (active) { try { prune(value); } catch {} } return value; };
    const wrappedParse = function (...args) {
      const value = Reflect.apply(originalParse, this, args);
      if (typeof args[0] === "string" && /"(?:adPlacements|playerAds|adSlots)"/.test(args[0])) return clean(value);
      return value;
    };
    target.JSON.parse = wrappedParse;
    const wrappedJSON = async function (...args) {
      const value = await Reflect.apply(originalJSON, this, args);
      try {
        const url = new URL(this.url);
        if (["www.youtube.com", "m.youtube.com", "www.youtube-nocookie.com"].includes(url.hostname) &&
            /^\/youtubei\/v1\/(player|next|browse|navigation\/resolve_url)\/?$/.test(url.pathname)) return clean(value);
      } catch {}
      return value;
    };
    if (originalJSON) responsePrototype.json = wrappedJSON;
    const getter = () => initialValue;
    const setter = value => { initialAssigned = true; initialValue = clean(value); };
    if (!originalInitial || (originalInitial.configurable && "value" in originalInitial)) {
      initialValue = clean(initialValue);
      Object.defineProperty(target, "ytInitialPlayerResponse", {
        configurable: true, enumerable: originalInitial?.enumerable ?? true, get: getter, set: setter
      });
    }
    return () => {
      active = false;
      if (target.JSON.parse === wrappedParse) target.JSON.parse = originalParse;
      if (originalJSON && responsePrototype.json === wrappedJSON) responsePrototype.json = originalJSON;
      if (Object.getOwnPropertyDescriptor(target, "ytInitialPlayerResponse")?.get === getter) {
        if (originalInitial) Object.defineProperty(target, "ytInitialPlayerResponse", { ...originalInitial, value: initialValue });
        else if (initialAssigned) Object.defineProperty(target, "ytInitialPlayerResponse", { configurable: true, writable: true, enumerable: true, value: initialValue });
        else Reflect.deleteProperty(target, "ytInitialPlayerResponse");
      }
    };
  }
  globalThis.QuietBlockYouTubeData = Object.freeze({ prune, install });
})();
