"use strict";
let rejects=0, accepts=0;
function update() { document.querySelector("#counts").textContent="Reject clicks: "+rejects+" · Accept clicks: "+accepts; }
setTimeout(() => {
  const banner=document.createElement("section"); banner.id="onetrust-banner-sdk";
  const text=document.createElement("p"); text.textContent="Test cookie banner: choose whether optional cookies are allowed.";
  const reject=document.createElement("button"); reject.id="onetrust-reject-all-handler"; reject.textContent="Reject all";
  const accept=document.createElement("button"); accept.id="onetrust-accept-btn-handler"; accept.textContent="Accept all";
  reject.addEventListener("click",()=>{ rejects++; update(); banner.remove(); document.querySelector("#result").textContent="PASS — rejection clicked; banner dismissed."; });
  accept.addEventListener("click",()=>{ accepts++; update(); document.querySelector("#result").textContent="FAIL — accept was clicked."; });
  banner.append(text,reject,accept);document.querySelector("#fixture").append(banner);
},800);
