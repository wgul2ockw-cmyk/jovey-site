import assert from "node:assert/strict";
import vm from "node:vm";
import { readFile } from "node:fs/promises";
import { createYouTubeControls } from "../youtube-controls.mjs";
const dataSource = await readFile(new URL("../youtube-data.js", import.meta.url), "utf8");
const realm = vm.createContext({ URL });
vm.runInContext(dataSource, realm);
const { prune } = realm.QuietBlockYouTubeData;
const payload = () => ({ videoDetails: { videoId: "local-test", title: "Video" },
  playabilityStatus: { status: "OK" }, streamingData: { formats: [{ url: "https://example.org/video" }] },
  captions: { keep: true }, adPlacements: [{}], playerAds: [{}], adSlots: [{}] });
let passed=0;
async function check(name, task) { await task(); passed++; console.log("PASS " + name); }
await check("remove ad arrays while preserving playback data", () => {
  const p=payload(), formats=p.streamingData;
  assert.equal(prune(p),p); assert(!("adPlacements" in p)); assert(!("playerAds" in p)); assert(!("adSlots" in p));
  assert.equal(p.streamingData,formats); assert.equal(p.videoDetails.title,"Video"); assert.equal(p.captions.keep,true);
});
await check("nested player payloads are filtered", () => {
  const p={ endpoint: { watchEndpoint: { unserializedPrefetchData: { playerResponse: payload() } } } };
  prune(p); assert(!p.endpoint.watchEndpoint.unserializedPrefetchData.playerResponse.playerAds);
});
await check("unrelated ad-like keys and error responses are preserved", () => {
  const p={ playerAds:[1], adPlacements:[2], playabilityStatus:{status:"ERROR"} }; const copy=JSON.stringify(p);
  prune(p); assert.equal(JSON.stringify(p),copy);
});
await check("getters, cycles and frozen payloads are safe", () => {
  const p=payload();p.self=p;Object.defineProperty(p,"secret",{enumerable:true,get(){throw new Error("getter accessed");}});
  assert.doesNotThrow(()=>prune(p));
  const f=Object.freeze(payload());assert.doesNotThrow(()=>prune(f));assert(f.playerAds);
});
vm.runInContext('globalThis.Response = class { constructor(value,url){this.value=value;this.url=url;} json(){return Promise.resolve(this.value);} }; globalThis.originalParse=JSON.parse; globalThis.originalJSON=Response.prototype.json; globalThis.dispose=QuietBlockYouTubeData.install(globalThis);',realm);
await check("JSON parse retains error and reviver behavior", () => {
  assert.equal(vm.runInContext('JSON.parse(\'{"n":2}\', (k,v)=>k==="n"?v+1:v).n',realm),3);
  assert.throws(()=>vm.runInContext('JSON.parse("invalid")',realm));
  realm.fixtureJSON=JSON.stringify(payload());
  assert.equal(vm.runInContext('JSON.parse(fixtureJSON).playerAds',realm),undefined);
});
await check("initial player assignment is filtered without breaking variable reads", () => {
  realm.initialPayload=payload();vm.runInContext('ytInitialPlayerResponse=initialPayload;',realm);
  assert.equal(realm.ytInitialPlayerResponse,realm.initialPayload);assert(!realm.initialPayload.playerAds);
});
await check("response JSON hook is restricted to exact YouTube API hosts and paths", async () => {
  realm.a=payload();realm.b=payload();realm.c=payload();
  await vm.runInContext('new Response(a,"https://www.youtube.com/youtubei/v1/player?key=test").json()',realm);
  await vm.runInContext('new Response(b,"https://www.youtube.com.example.org/youtubei/v1/player").json()',realm);
  await vm.runInContext('new Response(c,"https://www.youtube.com/account").json()',realm);
  assert(!realm.a.playerAds);assert(realm.b.playerAds);assert(realm.c.playerAds);
});
await check("turning off restores hooks without retaining original player responses", () => {
  vm.runInContext('dispose();',realm);
  assert.equal(vm.runInContext('JSON.parse===originalParse && Response.prototype.json===originalJSON',realm),true);
  realm.after=payload();vm.runInContext('ytInitialPlayerResponse=after;',realm);assert(realm.after.playerAds);
});
function controlsFixture({ granted=true, fail=false }={}) {
  let registrations=[]; const state={};
  const api={ permissions:{contains:async()=>granted}, storage:{local:{get:async key=>({[key]:state[key]}),set:async values=>Object.assign(state,values)}},
    scripting:{getRegisteredContentScripts:async()=>registrations,
      registerContentScripts:async value=>{if(fail)throw new Error("register failed");registrations=value;},
      unregisterContentScripts:async()=>{registrations=[];}}};
  return { controls:createYouTubeControls(api), state, scripts:()=>registrations };
}
await check("missing permission never activates", async()=>{
  const f=controlsFixture({granted:false});await assert.rejects(f.controls.enable(),/not been granted/);assert.equal(f.scripts().length,0);
});
await check("only YouTube hosts get early player filtering; disable removes both registrations", async()=>{
  const f=controlsFixture();assert.equal((await f.controls.enable()).enabled,true);
  assert.equal(f.scripts()[0].world,"MAIN");assert.equal(f.scripts()[0].runAt,"document_start");
  assert(f.scripts().every(s=>s.matches.every(m=>/^https:\/\/(www\.youtube\.com|m\.youtube\.com|www\.youtube-nocookie\.com)\/\*$/.test(m))));
  assert.equal((await f.controls.disable()).enabled,false);assert.equal(f.scripts().length,0);
});
await check("registration failure leaves the setting off",async()=>{
  const f=controlsFixture({fail:true});await assert.rejects(f.controls.enable(),/failed/);assert.equal(f.state.youtubeEnabled,false);
});
await check("no remote requests or private browsing data persistence",async()=>{
  const p=await readFile(new URL("../youtube-player.js",import.meta.url),"utf8");
  assert(!/\bfetch\s*\(|XMLHttpRequest|sendBeacon|document\.cookie|localStorage/.test(dataSource+p));
  assert(!/currentTime\s*=|playbackRate\s*=|\.muted\s*=|\.volume\s*=/.test(p));
});
console.log(passed+" YouTube data and permission checks passed.");
