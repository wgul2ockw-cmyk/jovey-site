import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import vm from "node:vm";
import { createBannerControls, bannerScriptId } from "../banner-controls.mjs";

function fixture({ granted = false, scriptingGranted = granted, enabled = false, registered = false, failRegister = false } = {}) {
  const data = { cookieBannerEnabled: enabled };
  const calls = [];
  const api = {
    permissions: {
      contains: async request => request.origins ? granted : scriptingGranted,
      remove: async request => { assert.deepEqual(request.permissions, ["scripting"]); calls.push("remove"); granted = false; scriptingGranted = false; return true; }
    },
    storage: { local: {
      get: async key => ({ [key]: data[key] }),
      set: async value => { Object.assign(data, value); calls.push("enabled=" + value.cookieBannerEnabled); }
    } },
    scripting: {
      getRegisteredContentScripts: async () => registered ? [{ id: bannerScriptId }] : [],
      registerContentScripts: async scripts => {
        assert.equal(scripts[0].world, "ISOLATED");
        assert.equal(scripts[0].persistAcrossSessions, true);
        assert.deepEqual(scripts[0].matches, ["http://*/*", "https://*/*"]);
        if (failRegister) throw new Error("Registration failed");
        registered = true; calls.push("register");
      },
      updateContentScripts: async () => { calls.push("update"); },
      unregisterContentScripts: async () => { registered = false; calls.push("unregister"); }
    }
  };
  return { controls: createBannerControls(api), data, calls };
}
let passed = 0;
async function check(name, operation) { await operation(); passed++; console.log("PASS " + name); }
await check("no permission means no script registration", async () => {
  const f = fixture();
  assert.equal((await f.controls.read()).enabled, false);
  await assert.rejects(f.controls.enable(), /not granted/);
  assert.deepEqual(f.calls, []);
});
await check("grant alone does not activate; explicit enable registers isolated script", async () => {
  const f = fixture({ granted: true });
  assert.equal((await f.controls.read()).enabled, false);
  assert.equal((await f.controls.enable()).enabled, true);
  assert.deepEqual(f.calls, ["enabled=false", "register", "enabled=true"]);
});
await check("registration failure leaves automatic rejection off", async () => {
  const f = fixture({ granted: true, failRegister: true });
  await assert.rejects(f.controls.enable(), /Registration failed/);
  assert.equal(f.data.cookieBannerEnabled, false);
});
await check("disable stops existing scripts before unregistering and removes only banner access", async () => {
  const f = fixture({ granted: true, enabled: true, registered: true });
  assert.equal((await f.controls.disable()).enabled, false);
  assert.deepEqual(f.calls, ["enabled=false", "unregister", "remove"]);
});
await check("revoked access cannot be silently re-enabled after update", async () => {
  const f = fixture({ enabled: true, registered: true });
  assert.equal((await f.controls.reconcile()).enabled, false);
  assert.equal(f.data.cookieBannerEnabled, false);
  assert(!f.calls.includes("register"));
});
await check("existing enabled registration survives reconciliation without a toggle race", async () => {
  const f = fixture({ granted: true, enabled: true, registered: true });
  assert.equal((await f.controls.reconcile()).enabled, true);
  assert.deepEqual(f.calls, []);
});
await check("partial permission removal still allows cleanup without a missing-script error", async () => {
  const f = fixture({ scriptingGranted: true });
  const state = await f.controls.read();
  assert.equal(state.enabled, false);
  assert.equal(state.scriptAccess, true);
  assert.equal((await f.controls.disable()).scriptAccess, false);
  assert.deepEqual(f.calls, ["enabled=false", "remove"]);
});
const source = await readFile(new URL("../consent-engine.js", import.meta.url), "utf8");
const context = vm.createContext({});
vm.runInContext(source, context);
const valid = (text, aria, generic = false) => context.QuietBlockConsent.validLabel({ textContent: text, getAttribute: () => aria }, generic);
await check("explicit rejection and necessary-only labels work across supported languages", async () => {
  for (const label of ["Reject all", "Deny", "Only necessary cookies", "Tout refuser", "Alle ablehnen", "ปฏิเสธทั้งหมด", "すべて拒否"]) assert.equal(valid(label, null), true, label);
});
await check("accept, save, close, mixed, and ambiguous labels never authorize a click", async () => {
  for (const label of ["Accept all", "Accept", "OK", "Save preferences", "Close", "Do not reject all", "Reject or accept all", "Reject all and subscribe", ""]) assert.equal(valid(label, null), false, label);
  assert.equal(valid("Reject all", "Accept all"), false);
  assert.equal(valid("Reject", null, true), false);
});
await check("manifest and engine contain no automatic required website access or remote execution", async () => {
  const m = JSON.parse(await readFile(new URL("../manifest.json", import.meta.url)));
  assert(!m.host_permissions && !m.content_scripts);
  assert.deepEqual(m.optional_permissions, ["privacy", "scripting"]);
  assert.deepEqual(m.optional_host_permissions, ["http://*/*", "https://*/*"]);
  assert(!/\b(fetch|XMLHttpRequest|eval)\s*\(|document\.cookie|localStorage|sessionStorage/.test(source));
});
console.log(passed + " banner permission and decision checks passed.");
