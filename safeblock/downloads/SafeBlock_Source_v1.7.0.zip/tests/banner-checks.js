"use strict";
const button = document.querySelector("#run-banner-checks");
const fixture = document.querySelector("#fixture");
const results = document.querySelector("#test-results");
const status = document.querySelector("#test-status");
button.addEventListener("click", async () => {
  button.disabled = true; results.replaceChildren();
  const cases = [
    ["OneTrust rejection", '<div id="onetrust-banner-sdk">Cookies<button id="onetrust-reject-all-handler">Reject all</button></div>', true],
    ["Cookiebot denial", '<div id="CybotCookiebotDialog">Cookies<button id="CybotCookiebotDialogBodyButtonDecline">Deny</button></div>', true],
    ["CookieYes rejection", '<div class="cky-consent-container">Cookies<button data-cky-tag="reject-button">Reject all</button></div>', true],
    ["Didomi rejection", '<div id="didomi-host">Cookies<button id="didomi-notice-disagree-button">Disagree</button></div>', true],
    ["Generic cookie dialog", '<div role="dialog">We use cookies<button>Reject all</button></div>', true],
    ["Necessary only", '<div role="dialog">Cookies<button>Only necessary cookies</button></div>', true],
    ["Thai rejection", '<div role="dialog">คุกกี้<button>ปฏิเสธทั้งหมด</button></div>', true],
    ["Accept all untouched", '<div role="dialog">Cookies<button>Accept all</button></div>', false],
    ["Unrelated dialog untouched", '<div role="dialog">Pending invitations<button>Reject all</button></div>', false],
    ["Hidden banner untouched", '<div id="onetrust-banner-sdk" hidden>Cookies<button id="onetrust-reject-all-handler">Reject all</button></div>', false],
    ["Disabled button untouched", '<div role="dialog">Cookies<button disabled>Reject all</button></div>', false],
    ["Mismatched label untouched", '<div role="dialog">Cookies<button aria-label="Accept all">Reject all</button></div>', false],
    ["Form submission untouched", '<form id="cookie-form">Cookies<button>Reject all</button></form>', false],
    ["Navigation link untouched", '<div role="dialog">Cookies<a href="https://example.org">Reject all</a></div>', false],
    ["Unknown choice untouched", '<div role="dialog">Cookies<button>Continue</button></div>', false],
    ["Revoked permission stops action", '<div role="dialog">Cookies<button>Reject all</button></div>', false, false]
  ];
  let passed = 0;
  try {
    for (const [name, html, expected, allowed = true] of cases) {
      fixture.innerHTML = html; // Static fixtures above; no website data is parsed.
      let clicks = 0;
      fixture.querySelectorAll("button, a").forEach(item => item.addEventListener("click", event => {
        event.preventDefault(); clicks++;
      }));
      const engine = QuietBlockConsent.createEngine(document, window, async () => allowed);
      const clicked = await engine.scan();
      await engine.scan(); // A second scan must never repeat the action.
      engine.stop();
      const ok = clicked === expected && clicks === Number(expected);
      passed += Number(ok);
      const row = document.createElement("li"); row.textContent = (ok ? "PASS — " : "FAIL — ") + name;
      results.append(row);
    }
    status.textContent = passed + " of " + cases.length + " banner checks passed";
  } catch (error) { status.textContent = "Check error: " + error.message; }
  finally { fixture.replaceChildren(); button.disabled = false; }
});
