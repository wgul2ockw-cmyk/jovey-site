import assert from 'node:assert/strict';
import { createNetworkControls } from '../network-core.mjs';
let rules=[];let enabled=['bundled'];let mutations=0;
const api={getDynamicRules:async()=>structuredClone(rules),getEnabledRulesets:async()=>enabled,
 updateDynamicRules:async({addRules=[],removeRuleIds=[]})=>{mutations++;rules=rules.filter(r=>!removeRuleIds.includes(r.id));rules.push(...addRules);}};
const c=createNetworkControls(api);let passed=0;
async function check(name,fn){await fn();passed++;console.log('PASS '+name);}
await check('opening the overview reads without changing protection',async()=>{assert.equal((await c.read()).paused,false);assert.equal(mutations,0);});
await check('website normalization and duplicate prevention',async()=>{await c.allow(' Example.COM. ');await c.allow('example.com');assert.equal(rules.length,1);assert.equal(rules[0].condition.initiatorDomains[0],'example.com');});
await check('pause and resume preserve website exceptions',async()=>{assert.equal((await c.toggle()).paused,true);assert.equal((await c.toggle()).paused,false);assert.equal(rules.length,1);});
await check('invalid domains never create a rule',async()=>{for(const s of ['https://example.com','example.com/path','example','-bad.example','bad..example', 'a'.repeat(254)+'.com'])await assert.rejects(c.allow(s),/Enter a domain/);assert.equal(rules.length,1);});
await check('removing an exception restores its network protection',async()=>{await c.remove(rules[0].id);assert.equal(rules.length,0);});
await check('unknown removal cannot remove the pause rule',async()=>{await c.toggle();await assert.rejects(c.remove(1),/no longer exists/);assert(rules.some(r=>r.id===1));});
await check('disabled bundled rules cannot appear active through toggle',async()=>{enabled=[];assert.equal((await c.read()).available,false);const before=mutations;await assert.rejects(c.toggle(),/Reload SafeBlock/);assert.equal(mutations,before);});
console.log(passed+' network control checks passed.');
