import test from 'node:test';
import assert from 'node:assert/strict';
import { createActivityControls } from '../activity-core.mjs';
import { readFile } from 'node:fs/promises';
const mock = data => {
  const calls=[];
  return {calls, api:{declarativeNetRequest:{setExtensionActionOptions:async value=>calls.push(value)},
    storage:{local:{get:async key=>{calls.push(key);return data;},set:()=>assert.fail('must not write legacy totals')}}}};
};
test('enables browser-managed count without request observation',async()=>{
 const {api,calls}=mock({}); await createActivityControls(api).enableBadge();
 assert.deepEqual(calls,[{displayActionCountAsBadgeText:true}]);
});
test('a new installation returns no fabricated lifetime total',async()=>{
 const {api}=mock({}); assert.deepEqual(await createActivityControls(api).read(),{mode:'native-badge',historical:null});
});
test('only aggregate legacy fields are returned and storage remains untouched',async()=>{
 const data={blockTotals:{lifetime:57,since:10000,untrusted:'discard'}};const {api}=mock(data);
 assert.deepEqual(await createActivityControls(api).read(),{mode:'native-badge',historical:{lifetime:57,since:10000}});
 assert.equal(data.blockTotals.lifetime,57);
});
test('invalid legacy totals cannot be presented as counts',async()=>{
 for(const value of [null,{}, {lifetime:-1,since:5},{lifetime:1.2,since:5},{lifetime:5,since:NaN},{lifetime:Infinity,since:5}]){
  assert.equal((await createActivityControls(mock({blockTotals:value}).api).read()).historical,null);
 }
});
test('badge failures propagate rather than reporting active',async()=>{
 const {api}=mock({});api.declarativeNetRequest.setExtensionActionOptions=async()=>{throw new Error('blocked')};
 await assert.rejects(createActivityControls(api).enableBadge(),/blocked/);
});
test('store manifest avoids debug and additional browsing permissions',async()=>{
 const manifest=JSON.parse(await readFile(new URL('../manifest.json',import.meta.url)));
 assert.deepEqual(manifest.permissions,['declarativeNetRequest','storage','activeTab']);
 for(const file of ['background.js','overview.js','checks.js','activity-core.mjs']){
  const s=await readFile(new URL('../'+file,import.meta.url),'utf8');
  assert(!/onRuleMatchedDebug|testMatchOutcome|getMatchedRules|webRequest|\.tabs\./.test(s),file);
 }
});
