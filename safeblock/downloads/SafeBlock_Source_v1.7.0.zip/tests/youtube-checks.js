"use strict";
document.querySelector("#run-youtube").addEventListener("click",()=>{
  const fixture=document.querySelector("#fixture"),results=document.querySelector("#results");results.replaceChildren();
  const cases=[
    ["Visible ad skip button",'<div id="movie_player" class="ad-showing"><button class="ytp-skip-ad-button">Skip</button></div>',true],
    ["Legacy skip button",'<div id="movie_player" class="ad-showing"><button class="ytp-ad-skip-button">Skip ad</button></div>',true],
    ["Modern skip button",'<div id="movie_player" class="ad-showing"><button class="ytp-ad-skip-button-modern">Skip ad</button></div>',true],
    ["Normal video untouched",'<div id="movie_player"><video></video><button class="ytp-skip-ad-button">Next</button></div>',false],
    ["Hidden skip untouched",'<div id="movie_player" class="ad-showing"><button hidden class="ytp-skip-ad-button">Skip</button></div>',false],
    ["Disabled skip untouched",'<div id="movie_player" class="ad-showing"><button disabled class="ytp-skip-ad-button">Skip</button></div>',false],
    ["Advertiser link untouched",'<div id="movie_player" class="ad-showing"><button>Visit advertiser</button></div>',false],
    ["Skip outside player untouched",'<div id="movie_player" class="ad-showing"></div><button class="ytp-skip-ad-button">Skip</button>',false],
    ["Form untouched",'<div id="movie_player" class="ad-showing"><form><button class="ytp-skip-ad-button">Skip</button></form></div>',false]
  ];
  let passed=0;
  for(const [name,html,expected] of cases){
    fixture.innerHTML=html;let clicks=0;
    fixture.querySelectorAll("button").forEach(b=>b.addEventListener("click",e=>{e.preventDefault();clicks++;}));
    const engine=QuietBlockYouTubePlayer.createPlayer(document,window);
    const clicked=engine.scan();engine.scan();engine.stop();
    const ok=clicked===expected&&clicks===Number(expected);passed+=Number(ok);
    const row=document.createElement("li");row.textContent=(ok?"PASS — ":"FAIL — ")+name;results.append(row);
  }
  fixture.replaceChildren();document.querySelector("#test-status").textContent=passed+" of "+cases.length+" player checks passed";
});
