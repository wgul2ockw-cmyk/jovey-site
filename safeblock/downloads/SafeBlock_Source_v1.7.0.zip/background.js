import { createBannerControls } from "./banner-controls.mjs";
import { createYouTubeControls } from "./youtube-controls.mjs";

const youtubeControls = createYouTubeControls(chrome);
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || message?.type !== "youtubeAllowed") return;
  let host;
  try { host = new URL(sender.url).hostname; } catch { sendResponse({ allowed: false }); return; }
  if (!["www.youtube.com", "m.youtube.com", "www.youtube-nocookie.com"].includes(host)) {
    sendResponse({ allowed: false }); return;
  }
  youtubeControls.read().then(state => sendResponse({ allowed: state.enabled }),
    () => sendResponse({ allowed: false }));
  return true;
});
chrome.runtime.onInstalled.addListener(() => { youtubeControls.reconcile().catch(() => {}); });
chrome.permissions.onRemoved.addListener(removed => {
  if (removed.permissions?.includes("scripting") || removed.origins?.length) {
    youtubeControls.reconcile().catch(() => {});
  }
});

const bannerControls = createBannerControls(chrome);
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || message?.type !== "bannerAllowed") return;
  if (!/^https?:\/\//.test(sender.url || "")) { sendResponse({ allowed: false }); return; }
  bannerControls.read().then(state => sendResponse({ allowed: state.enabled }),
    () => sendResponse({ allowed: false }));
  return true;
});
chrome.runtime.onInstalled.addListener(() => { bannerControls.reconcile().catch(() => {}); });
chrome.permissions.onRemoved.addListener(removed => {
  if (removed.permissions?.includes("scripting") || removed.origins?.length) {
    bannerControls.reconcile().catch(() => {});
  }
});

// Supported in Chrome Web Store builds. Chrome renders the page count itself.
// Legacy totals remain untouched and are shown only as historical records.
import { createActivityControls } from "./activity-core.mjs";
const activity = createActivityControls(chrome);
const activateBadge = () => activity.enableBadge().catch(error => console.warn("SafeBlock badge:", error.message));
chrome.runtime.onInstalled.addListener(activateBadge);
chrome.runtime.onStartup.addListener(activateBadge);
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Content scripts cannot request even aggregate historical information.
  if (sender.id !== chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL("")) || message?.type !== "getActivity") return;
  activity.enableBadge().then(() => activity.read()).then(sendResponse, error => sendResponse({ error: error.message }));
  return true;
});
