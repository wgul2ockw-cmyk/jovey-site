"use strict";
(() => {
  const skipSelector = "button.ytp-skip-ad-button, button.ytp-ad-skip-button, button.ytp-ad-skip-button-modern";
  const adSelector = "ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-promoted-sparkles-web-renderer, ytd-promoted-video-renderer, ytd-display-ad-renderer, #player-ads";
  function createPlayer(doc, view) {
    let attempted = new WeakSet();
    let observer, timer, stopped = false;
    const style = doc.createElement("style");
    style.textContent = adSelector + "{display:none!important;}";
    function scan() {
      if (stopped) return false;
      const player = doc.querySelector("#movie_player.ad-showing");
      if (!player) { attempted = new WeakSet(); return false; }
      for (const button of player.querySelectorAll(skipSelector)) {
        if (attempted.has(button) || button.disabled || button.getAttribute("aria-disabled") === "true" ||
            button.closest('[hidden], [inert], [aria-hidden="true"]') || button.form) continue;
        const css = view.getComputedStyle(button), rect = button.getBoundingClientRect();
        if (css.display === "none" || css.visibility !== "visible" || Number(css.opacity) === 0 || rect.width < 1 || rect.height < 1) continue;
        const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
        const top = doc.elementFromPoint(x, y);
        if (top !== button && !button.contains(top)) continue;
        attempted.add(button);
        button.click();
        return true;
      }
      return false;
    }
    function start() {
      if (stopped || observer) return;
      (doc.head || doc.documentElement).append(style);
      observer = new view.MutationObserver(() => {
        if (timer || stopped) return;
        timer = view.setTimeout(() => { timer = undefined; scan(); }, 200);
      });
      observer.observe(doc.documentElement, { subtree: true, childList: true, attributes: true,
        attributeFilter: ["class", "style", "hidden", "disabled", "aria-disabled"] });
      scan();
    }
    function stop() { stopped = true; observer?.disconnect(); view.clearTimeout(timer); style.remove(); }
    return { start, stop, scan };
  }
  globalThis.QuietBlockYouTubePlayer = Object.freeze({ createPlayer });
})();
