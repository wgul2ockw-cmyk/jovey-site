"use strict";
(() => {
  if (!["www.youtube.com", "m.youtube.com", "www.youtube-nocookie.com"].includes(location.hostname)) return;
  const dispose = QuietBlockYouTubeData.install(window);
  // One-way stop only. Website events cannot enable features or reach extension APIs.
  window.addEventListener("quietblock-stop-youtube", dispose, { once: true });
})();
