# SafeBlock for Chrome 1.7.0

SafeBlock is the renamed QuietBlock project. This release prepares the Chrome Web Store package and adds a compact toolbar
popup with current-site status, a page count, and an allow/block control. It follows your
Mac's light/dark appearance by default, with optional manual appearance choices.

## What it does

- Blocks third-party requests to 3,560 bundled ad/tracker domains locally.
- Uses Chrome’s native per-page blocked-request count on the toolbar icon and,
  when available after opening the popup, in the popup. Counts reset on navigation.
- Lets you allow the current domain (and subdomains), then restore blocking.
- Preserves earlier developer-build totals as historical data. New session and
  lifetime totals are not collected in the Store build.
- Offers six optional Chrome privacy settings with verified effective status.
- Optionally chooses explicit rejection on supported cookie banners.
- Offers experimental YouTube player filtering and automatic available Skip.
- Lets you pause network blocking or add domain exceptions.

Filtering has no telemetry, accounts, external DNS, hosted filtering, or remote
code updates. Fonts are bundled, so the interface makes no font-service requests.

## Install on a Mac

1. Extract the ZIP and keep the extracted folder containing `manifest.json` in a permanent location.
2. Open `chrome://extensions` in desktop Chrome.
3. Enable Developer mode, click **Load unpacked**, and choose that extracted folder.
4. Pin SafeBlock through Chrome's Extensions menu.
5. Open SafeBlock → **Open dashboard**. Privacy controls, cookie rejection, and
   YouTube filtering are separate opt-in features. Chrome asks for the required
   access when you enable them. Reload open websites after changes.

**Already using QuietBlock?** Back up its existing source folder, then replace
that folder's contents with this version and click **Reload** on its existing
Chrome extension card. Keep the existing folder path and extension installation
to preserve its identity, historical totals, permissions, and exceptions. Loading a
second folder creates a separate installation. Do not remove the old extension
if you want to retain its locally saved data. Earlier totals remain historical and no longer increase. A future Store
installation has a different extension identity: local settings and old totals do
not transfer automatically. Back up the old installation before removing it.

The Store ZIP has `manifest.json` at its root and is a submission candidate,
not an approved Chrome Web Store release or a signed native app. Chrome on iPhone and iPad cannot load it.
No working or signed iOS binary is included or claimed.

## Controls and limits

**Pause blocking** and **Allowed websites** change only network request rules.
They do not change Chrome privacy settings, cookie rejection, or YouTube's
separate filtering switch. Website exceptions include subdomains.

Privacy controls can block third-party cookies, link-click reports, predictive
page loading, and supported browser advertising features. First-party cookies
remain. Existing cookies are not erased. Chrome policies, other extensions,
site exceptions, storage-access grants, and partitioned storage can affect
what is allowed. “Use Chrome setting” releases one override; “Release all
controls” releases overrides and the optional privacy permission.

Cookie rejection uses optional scripting and HTTP/HTTPS website access.
It looks for explicit visible rejection/necessary-only buttons locally,
never accepts all or merely hides a banner. Supported examples include
OneTrust, Cookiebot, CookieYes, and Didomi. Unknown wording, paywalls, closed
shadow roots, and native-app prompts can remain. It attempts at most one
rejection per frame in the first 90 seconds. A website may ignore a choice.
Removing its shared website/scripting access also disables YouTube filtering.

YouTube filtering is experimental. It removes recognized player ad arrays,
hides specific ad panels, and presses a visible enabled Skip button when
available. Skipping is not the same as blocking an ad download. It does not
seek, change playback speed, or adjust volume. Some ads, anti-adblock notices,
stream-integrated ads, and creator sponsorships can remain. It runs only on
www.youtube.com, m.youtube.com, and www.youtube-nocookie.com. Reload YouTube
when enabling or disabling it. Reliable comprehensive ad removal is not claimed.

## Privacy and permissions

Required: `declarativeNetRequest`, `storage`, `activeTab`.
Optional: `privacy`, `scripting`, and HTTP/HTTPS host access.
`activeTab` gives temporary access when you open the extension. The popup reads
only the active tab's URL to identify the domain and Chrome's own count for that
tab. It does not store URLs, titles, favicons, or browsing history. Domain exceptions
are saved only when you choose to allow a site.

The debugging/reporting permission and debug event listener have been removed.
Chrome manages page counts; no URL observation or background polling is used.
Local storage holds feature booleans, appearance, and any pre-existing historical
totals. Website exceptions are Chrome dynamic rules. No synchronized storage,
telemetry, remote code, external DNS, or account is used. Optional page scripts
inspect website elements/player responses locally without retaining them.

The extension does not promise anonymity or protection from all cyberattacks.
It leaves Safe Browsing, passwords, DNS, proxy, and browser-account settings alone.

## Verification

Run `node --test tests/*.test.mjs` (Node 18+). There are 56 checks covering privacy,
banner decisions, YouTube payload handling, network exceptions, production activity,
and current-site actions. These use synthetic data and simulated Chrome APIs.

The 1.7 dashboard was opened in the installed desktop Chrome extension. Existing
optional protection states and historical totals were read successfully. The compact popup displayed three blocked requests during a controlled test;
the local control request completed. Allow/block for the test site was verified
and removed, and Diagnostics reported zero exceptions with blocking on.
Additional runtime results are recorded in the release verification file. Automated tests do
not prove comprehensive real-world ad coverage or reliable YouTube ad removal.

To create reproducible root-manifest Store and source ZIPs, run
`python3 scripts/prepare_store.py` from the project (script is outside this archive).
The Store ZIP excludes development tests. The source ZIP includes them.

## Source and fonts

Bundled domain rules: Peter Lowe's list, retrieved November 8, 2026.
Source material and its checksum are under `rules/`.
https://pgl.yoyo.org/adservers/

Prata, Quicksand, and Anuphan are bundled from the Google Fonts source repository
under their SIL Open Font Licenses. License notices are in `assets/fonts/`.
https://github.com/google/fonts/tree/main/ofl/prata
https://github.com/google/fonts/tree/main/ofl/quicksand
https://github.com/google/fonts/tree/main/ofl/anuphan

Some internal `QuietBlock` names remain intentionally unchanged so previously
registered scripts and local state remain compatible. User-facing branding
and the extension manifest use SafeBlock.
