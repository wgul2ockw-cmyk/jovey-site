"use strict";

// Bundled, opt-out-only rules. No page functions, remote rules, cookies, or forms.
(() => {
  const rules = Object.freeze([
    { root: "#onetrust-banner-sdk", button: "#onetrust-reject-all-handler" },
    { root: "#CybotCookiebotDialog", button: "#CybotCookiebotDialogBodyButtonDecline, #CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll" },
    { root: ".cky-consent-container", button: '[data-cky-tag="reject-button"]' },
    { root: "#didomi-host", button: "#didomi-notice-disagree-button, .didomi-continue-without-agreeing" }
  ]);
  const exactLabels = new Set([
    "reject", "reject all", "reject all cookies", "reject optional cookies", "reject non-essential cookies",
    "decline", "decline all", "decline optional cookies", "deny", "deny all", "disagree",
    "necessary only", "only necessary", "only necessary cookies", "use necessary cookies only",
    "allow only necessary cookies", "accept only necessary cookies", "essential cookies only",
    "continue without accepting", "continue without agreeing", "continue without consent",
    "tout refuser", "refuser", "refuser tout", "continuer sans accepter",
    "alle ablehnen", "ablehnen", "nur notwendige cookies", "nur notwendige",
    "rechazar todo", "rechazar todas", "rechazar", "solo necesarias",
    "rifiuta tutti", "rifiuta", "solo necessari", "rejeitar todos", "rejeitar",
    "alles weigeren", "weigeren", "alleen noodzakelijk",
    "ปฏิเสธ", "ปฏิเสธทั้งหมด", "เฉพาะคุกกี้ที่จำเป็น", "ยอมรับเฉพาะคุกกี้ที่จำเป็น",
    "すべて拒否", "すべてを拒否", "拒否", "拒绝全部", "全部拒绝", "拒絕全部", "全部拒絕", "모두 거부"
  ]);
  const genericLabels = new Set([...exactLabels].filter(value => ![
    "reject", "decline", "deny", "disagree", "refuser", "ablehnen", "rechazar", "rifiuta", "rejeitar", "weigeren", "ปฏิเสธ", "拒否"
  ].includes(value)));
  const normalize = text => String(text || "").normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();

  function validLabel(button, generic = false) {
    const labels = [button.textContent, button.getAttribute("aria-label")].map(normalize).filter(Boolean);
    const allowed = generic ? genericLabels : exactLabels;
    // Both visible text and accessible label must agree on a rejection action.
    return labels.length > 0 && labels.every(label => allowed.has(label));
  }

  function createEngine(doc, view, authorize) {
    let stopped = false;
    let busy = false;
    let observer;
    let scheduled;
    let expiry;
    const attempted = new WeakSet();

    function visible(element) {
      if (!element.isConnected || element.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
      const style = view.getComputedStyle(element);
      if (style.display === "none" || style.visibility !== "visible" || Number(style.opacity) === 0) return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 1 && rect.height > 1 && rect.bottom > 0 && rect.right > 0 &&
        rect.top < view.innerHeight && rect.left < view.innerWidth;
    }

    function candidate(root, button, generic = false) {
      if (attempted.has(button) || !visible(root) || !visible(button)) return false;
      if (!button.matches('button, [role="button"], a') || button.matches(':disabled, [aria-disabled="true"]')) return false;
      // Do not submit a form or follow a navigation link, even if mislabeled.
      if (button.form || button.closest("form")) return false;
      if (button.matches("a") && ![null, "", "#"].includes(button.getAttribute("href"))) return false;
      if (!validLabel(button, generic)) return false;
      const r = button.getBoundingClientRect();
      const x = Math.max(0, Math.min(view.innerWidth - 1, r.left + r.width / 2));
      const y = Math.max(0, Math.min(view.innerHeight - 1, r.top + r.height / 2));
      const top = doc.elementFromPoint(x, y);
      return top === button || button.contains(top);
    }

    function find() {
      for (const rule of rules) {
        for (const root of [...doc.querySelectorAll(rule.root)].slice(0, 5)) {
          for (const button of [...root.querySelectorAll(rule.button)].slice(0, 5)) {
            if (candidate(root, button)) return { root, button, generic: false };
          }
        }
      }
      // Conservative fallback: a cookie-specific container and explicit reject-all
      // or necessary-only label. Never infer consent from Close, OK, or Save.
      const roots = doc.querySelectorAll('[role="dialog"], dialog[open], [id*="cookie" i], [id*="consent" i], [class*="cookie-banner" i], [class*="cookie-consent" i]');
      for (const root of [...roots].slice(0, 80)) {
        if (root === doc.body || root === doc.documentElement || !visible(root)) continue;
        if ((root.textContent || "").length > 8000) continue;
        // Keep boundaries between text nodes: "cookies<button>Reject" is two words.
        const walker = doc.createTreeWalker(root, view.NodeFilter.SHOW_TEXT);
        const pieces = [];
        let node;
        while ((node = walker.nextNode()) && pieces.length < 200) pieces.push(node.nodeValue);
        const text = pieces.join(" ");
        if (!/(\bcookies?\b|คุกกี้|クッキー|쿠키)/i.test(text)) continue;
        for (const button of [...root.querySelectorAll('button, [role="button"], a')].slice(0, 20)) {
          if (candidate(root, button, true)) return { root, button, generic: true };
        }
      }
      return null;
    }

    function stop() {
      stopped = true;
      observer?.disconnect();
      view.clearTimeout(scheduled);
      view.clearTimeout(expiry);
    }

    async function scan() {
      if (stopped || busy) return false;
      const match = find();
      if (!match) return false;
      busy = true;
      try {
        // Recheck permission and the user toggle immediately before each action.
        if (!await authorize()) { stop(); return false; }
        if (stopped || !candidate(match.root, match.button, match.generic)) return false;
        attempted.add(match.button);
        stop(); // One action per document: never loop or override later user choices.
        match.button.click();
        return true;
      } catch {
        stop();
        return false;
      } finally { busy = false; }
    }

    function start() {
      if (stopped || observer) return;
      observer = new view.MutationObserver(() => {
        if (scheduled || stopped) return;
        scheduled = view.setTimeout(() => { scheduled = undefined; scan(); }, 200);
      });
      observer.observe(doc.documentElement, { childList: true, subtree: true, attributes: true,
        attributeFilter: ["class", "style", "hidden", "aria-hidden", "disabled"] });
      expiry = view.setTimeout(stop, 90000);
      scan();
    }
    return { start, stop, scan };
  }
  globalThis.QuietBlockConsent = Object.freeze({ createEngine, validLabel });
})();
