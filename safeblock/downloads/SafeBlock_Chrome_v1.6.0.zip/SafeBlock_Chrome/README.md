# SafeBlock for Chrome 1.6.0

SafeBlock is the renamed QuietBlock project. This release adds a new dashboard
and toolbar popup using Jovey's typography and visual style. It follows your
Mac's light/dark appearance by default, with optional manual appearance choices.

## What it does

- Blocks third-party requests to 3,560 bundled ad/tracker domains locally.
- Shows session and lifetime blocked-request totals. These count requests,
  not unique ads, blocked cookies, banner choices, or YouTube skip actions.
- Offers six optional Chrome privacy settings with verified effective status.
- Optionally chooses explicit rejection on supported cookie banners.
- Offers experimental YouTube player filtering and automatic available Skip.
- Lets you pause network blocking or add domain exceptions.

Filtering has no telemetry, accounts, external DNS, hosted filtering, or remote
code updates. Fonts are bundled, so the interface makes no font-service requests.

## Install on a Mac

1. Extract the ZIP and keep `SafeBlock_Chrome` in a permanent folder.
2. Open `chrome://extensions` in desktop Chrome.
3. Enable Developer mode, click **Load unpacked**, and choose `SafeBlock_Chrome`.
4. Pin SafeBlock through Chrome's Extensions menu.
5. Open SafeBlock → **Open dashboard**. Privacy controls, cookie rejection, and
   YouTube filtering are separate opt-in features. Chrome asks for the required
   access when you enable them. Reload open websites after changes.

**Already using QuietBlock?** Back up its existing source folder, then replace
that folder's contents with this version and click **Reload** on its existing
Chrome extension card. Keep the existing folder path and extension installation
to preserve its identity, counters, permissions, and exceptions. Loading a
second folder creates a separate installation. Do not remove the old extension
if you want to retain its locally saved data. Session totals reset on reload;
lifetime totals survive an in-place update.

This source is an unpacked desktop Chrome extension, not a Chrome Web Store
release or a signed native app. Chrome on iPhone and iPad cannot load it.
No working or signed iOS binary is included or claimed.

## Controls and limits

**Pause blocking** and **Allowed websites** change only network request rules.
They do not change Chrome privacy settings, cookie rejection, or YouTube's
separate filtering switch. Website exceptions include subdomains.

Privacy controls can block third-party cookies, link-click reports, predictive
page loading, and supported browser advertising features. First-party cookies
remain. Existing cookies are not erased. Chrome policies, other extensions,
site exceptions, storage-access grants, and partitioned storage can affect
what is allowed. “Use Chrome setting” releases one override; “Release all
controls” releases overrides and the optional privacy permission.

Cookie rejection uses optional scripting and HTTP/HTTPS website access.
It looks for explicit visible rejection/necessary-only buttons locally,
never accepts all or merely hides a banner. Supported examples include
OneTrust, Cookiebot, CookieYes, and Didomi. Unknown wording, paywalls, closed
shadow roots, and native-app prompts can remain. It attempts at most one
rejection per frame in the first 90 seconds. A website may ignore a choice.
Removing its shared website/scripting access also disables YouTube filtering.

YouTube filtering is experimental. It removes recognized player ad arrays,
hides specific ad panels, and presses a visible enabled Skip button when
available. Skipping is not the same as blocking an ad download. It does not
seek, change playback speed, or adjust volume. Some ads, anti-adblock notices,
stream-integrated ads, and creator sponsorships can remain. It runs only on
www.youtube.com, m.youtube.com, and www.youtube-nocookie.com. Reload YouTube
when enabling or disabling it. Reliable comprehensive ad removal is not claimed.

## Privacy and permissions

Required: `declarativeNetRequest`, `declarativeNetRequestFeedback`, `storage`.
Optional: `privacy`, `scripting`, and HTTP/HTTPS host access.
This UI release adds no new browser permission.

The rule-match reporting permission can supply request URLs. The counter reads
only the rule's ruleset ID; it never stores request details. Local extension
storage contains aggregate totals, a counting start time, a session baseline,
feature booleans, and the appearance choice. Domain exceptions are local Chrome
dynamic rules. No synchronized storage, watch history, page contents, or input
values are collected. The optional page-side scripts inspect only the page
elements/player data needed for their functions, without retaining that data.

The extension does not promise anonymity or protection from all cyberattacks.
It leaves Safe Browsing, passwords, DNS, proxy, and browser-account settings alone.

## Verification

On November 12, 2026, 38 automated checks passed: 9 privacy-controller checks,
10 banner checks, 12 YouTube checks, and 7 network-control checks. Tests use
synthetic payloads and simulated Chrome APIs. Run each with Node 18+:

```
node tests/privacy.test.mjs
node tests/banners.test.mjs
node tests/youtube.test.mjs
node tests/network.test.mjs
```

The UI preview was exercised in Chromium for page navigation, appearance
selection, pause/resume, invalid website input, adding/removing an exception,
individual privacy restoration, and cookie/YouTube toggles. Preview controls
use sample state and do not change Chrome protection. Actual Chrome rule checks
are deliberately unavailable in the website preview.

The prior QuietBlock 1.5.0 build had a limited live Mac Chrome playback check:
a YouTube video played, but no real-ad suppression was observed. This release's
new UI has not yet been installed or runtime-tested as an extension on the M4.
No new real-world ad-blocking, full Chrome restart, or mobile testing is claimed.
The filtering rules and page engines are unchanged from 1.5.0; this release
changes branding, navigation, presentation, appearance, and the network UI controller.

## Source and fonts

Bundled domain rules: Peter Lowe's list, retrieved November 8, 2026.
Source material and its checksum are under `rules/`.
https://pgl.yoyo.org/adservers/

Prata, Quicksand, and Anuphan are bundled from the Google Fonts source repository
under their SIL Open Font Licenses. License notices are in `assets/fonts/`.
https://github.com/google/fonts/tree/main/ofl/prata
https://github.com/google/fonts/tree/main/ofl/quicksand
https://github.com/google/fonts/tree/main/ofl/anuphan

Some internal `QuietBlock` names remain intentionally unchanged so previously
registered scripts and local state remain compatible. User-facing branding
and the extension manifest use SafeBlock.
