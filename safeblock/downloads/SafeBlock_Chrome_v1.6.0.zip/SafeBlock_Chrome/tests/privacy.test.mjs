import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createPrivacyControls, protections, summarizePrivacy } from "../privacy-core.mjs";

function fixture({ granted = true, missing = [], locked = {}, failures = {}, bases = {} } = {}) {
  const calls = [];
  const overrides = new Map();
  const api = {
    privacy: { network: {}, websites: {} },
    permissions: {
      contains: async () => granted,
      remove: async () => { calls.push(["removePermission"]); granted = false; return true; }
    }
  };
  for (const spec of protections) {
    if (missing.includes(spec.key)) continue;
    api.privacy[spec.group][spec.key] = {
      get: async () => {
        if (failures[spec.key] === "get") throw new Error("Read failed");
        return {
          value: overrides.has(spec.key) ? overrides.get(spec.key) : (bases[spec.key] ?? true),
          levelOfControl: locked[spec.key] || (overrides.has(spec.key) ? "controlled_by_this_extension" : "controllable_by_this_extension")
        };
      },
      set: async details => {
        assert.equal(details.value, false, "never enable data sharing");
        assert.equal(details.scope, "regular");
        calls.push(["set", spec.key]);
        if (failures[spec.key] === "set") throw new Error("Write failed");
        if (failures[spec.key] !== "ignored") overrides.set(spec.key, details.value);
      },
      clear: async details => {
        assert.equal(details.scope, "regular");
        calls.push(["clear", spec.key]);
        if (failures[spec.key] === "clear") throw new Error("Clear failed");
        overrides.delete(spec.key);
      }
    };
  }
  // Any expansion into unrelated security settings or private cookie data fails.
  Object.defineProperty(api, "cookies", { get() { throw new Error("Must not read cookies"); } });
  Object.defineProperty(api.privacy, "services", { get() { throw new Error("Must not change Safe Browsing or other services"); } });
  return { api, calls, overrides, controls: createPrivacyControls(api) };
}

let passed = 0;
async function check(name, operation) {
  await operation(); passed++; console.log("PASS " + name);
}

await check("no permission means no reads or mutations", async () => {
  const f = fixture({ granted: false });
  const state = await f.controls.read();
  assert(state.items.every(x => x.status === "permission-required"));
  await assert.rejects(f.controls.enable(), /not granted/);
  await f.controls.releaseAll();
  assert.deepEqual(f.calls, []);
});

await check("page load is read-only and enable verifies all six effective settings", async () => {
  const f = fixture();
  await f.controls.read(); assert.deepEqual(f.calls, []);
  const state = await f.controls.enable();
  assert.equal(f.calls.length, 6);
  assert(state.items.every(x => x.status === "protected"));
  assert.match(summarizePrivacy(state), /^6 of 6/);
});

await check("policy and other extensions retain control", async () => {
  const f = fixture({ locked: { thirdPartyCookiesAllowed: "not_controllable", topicsEnabled: "controlled_by_other_extensions" } });
  const state = await f.controls.enable();
  assert.equal(f.calls.length, 4);
  assert.equal(state.items[0].status, "unprotected");
  assert.match(summarizePrivacy(state), /^4 of 6/);
});

await check("missing retired APIs are reported without claiming protection", async () => {
  const f = fixture({ missing: ["topicsEnabled", "fledgeEnabled", "adMeasurementEnabled"] });
  const state = await f.controls.enable();
  assert.equal(state.items.filter(x => x.status === "unsupported").length, 3);
  assert.equal(f.calls.length, 3);
  assert.match(summarizePrivacy(state), /^3 of 3/);
});

await check("failed or ignored writes cannot appear protected", async () => {
  const f = fixture({ failures: { thirdPartyCookiesAllowed: "set", topicsEnabled: "ignored", fledgeEnabled: "get" } });
  const state = await f.controls.enable();
  assert.equal(state.errors.length, 2);
  assert.equal(state.items[0].status, "unprotected");
  assert.equal(state.items[3].status, "unprotected");
  assert.equal(state.items[4].status, "error");
  assert.match(summarizePrivacy(state), /^3 of 6/);
});

await check("release one restores the underlying preference without forcing true", async () => {
  const f = fixture({ bases: { thirdPartyCookiesAllowed: false } });
  await f.controls.enable();
  let state = await f.controls.releaseOne("thirdPartyCookiesAllowed");
  assert.equal(state.items[0].status, "protected");
  assert.equal(state.items[0].levelOfControl, "controllable_by_this_extension");
  state = await f.controls.releaseOne("hyperlinkAuditingEnabled");
  assert.equal(state.items[1].status, "unprotected");
  assert.equal(f.overrides.size, 4);
  await assert.rejects(f.controls.releaseOne("safeBrowsingEnabled"), /Unknown/);
});

await check("release all clears only our overrides and removes optional permission", async () => {
  const f = fixture();
  await f.controls.enable();
  const state = await f.controls.releaseAll();
  assert.equal(f.overrides.size, 0);
  assert.equal(state.granted, false);
  assert.deepEqual(f.calls.at(-1), ["removePermission"]);
});

await check("restoration failure retains permission so release can be retried", async () => {
  const f = fixture({ failures: { thirdPartyCookiesAllowed: "clear" } });
  await f.controls.enable();
  const state = await f.controls.releaseAll();
  assert.equal(state.granted, true);
  assert.equal(state.errors.length, 1);
  assert(!f.calls.some(x => x[0] === "removePermission"));
});

await check("required permissions remain limited and website access stays optional", async () => {
  const manifest = JSON.parse(await readFile(new URL("../manifest.json", import.meta.url)));
  assert.deepEqual(manifest.permissions, ["declarativeNetRequest", "declarativeNetRequestFeedback", "storage"]);
  assert.deepEqual(manifest.optional_permissions, ["privacy", "scripting"]);
  assert.deepEqual(manifest.optional_host_permissions, ["http://*/*", "https://*/*"]);
  assert(!manifest.host_permissions && !manifest.content_scripts);
  assert.match(manifest.content_security_policy.extension_pages, /connect-src 'none'/);
});

console.log(passed + " privacy checks passed.");
