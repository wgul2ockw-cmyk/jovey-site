import { createBannerControls } from "./banner-controls.mjs";
import { createYouTubeControls } from "./youtube-controls.mjs";

const youtubeControls = createYouTubeControls(chrome);
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || message?.type !== "youtubeAllowed") return;
  let host;
  try { host = new URL(sender.url).hostname; } catch { sendResponse({ allowed: false }); return; }
  if (!["www.youtube.com", "m.youtube.com", "www.youtube-nocookie.com"].includes(host)) {
    sendResponse({ allowed: false }); return;
  }
  youtubeControls.read().then(state => sendResponse({ allowed: state.enabled }),
    () => sendResponse({ allowed: false }));
  return true;
});
chrome.runtime.onInstalled.addListener(() => { youtubeControls.reconcile().catch(() => {}); });
chrome.permissions.onRemoved.addListener(removed => {
  if (removed.permissions?.includes("scripting") || removed.origins?.length) {
    youtubeControls.reconcile().catch(() => {});
  }
});

const bannerControls = createBannerControls(chrome);
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || message?.type !== "bannerAllowed") return;
  if (!/^https?:\/\//.test(sender.url || "")) { sendResponse({ allowed: false }); return; }
  bannerControls.read().then(state => sendResponse({ allowed: state.enabled }),
    () => sendResponse({ allowed: false }));
  return true;
});
chrome.runtime.onInstalled.addListener(() => { bannerControls.reconcile().catch(() => {}); });
chrome.permissions.onRemoved.addListener(removed => {
  if (removed.permissions?.includes("scripting") || removed.origins?.length) {
    bannerControls.reconcile().catch(() => {});
  }
});

// One writer serializes updates so simultaneous requests cannot lose increments.
// Only aggregate numbers and timestamps are saved. Request details are discarded.
let pending = Promise.resolve();
let counterError = "";

async function readTotals() {
  const { blockTotals } = await chrome.storage.local.get("blockTotals");
  const totals = blockTotals ?? { lifetime: 0, since: Date.now() };
  const { counterSession } = await chrome.storage.session.get("counterSession");
  const session = counterSession ?? { baseline: totals.lifetime };
  if (!blockTotals) await chrome.storage.local.set({ blockTotals: totals });
  if (!counterSession) await chrome.storage.session.set({ counterSession: session });
  return { totals, session };
}

function enqueue(operation) {
  const result = pending.then(operation);
  pending = result.catch(error => {
    counterError = error.message;
  });
  return result;
}

chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(({ rule }) => {
  // All bundled rules block requests. Dynamic pause/allow rules never count.
  if (rule.rulesetId !== "bundled") return;
  enqueue(async () => {
    const { totals } = await readTotals();
    await chrome.storage.local.set({
      blockTotals: { lifetime: totals.lifetime + 1, since: totals.since }
    });
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || message.type !== "getTotals") return;
  enqueue(async () => {
    const { totals, session } = await readTotals();
    return {
      lifetime: totals.lifetime,
      session: totals.lifetime - session.baseline,
      since: totals.since,
      error: counterError
    };
  }).then(sendResponse, error => sendResponse({ error: error.message }));
  return true;
});
